#version 130
uniform vec3 zenith;
uniform vec3 horizon;
uniform vec3 sunDir;
uniform vec3 sunColor;
uniform float sunVisible;
in vec3 dir;
out vec4 color;

void main() {
    vec3 d = normalize(dir);
    float h = clamp(d.z, 0.0, 1.0);
    vec3 c = mix(horizon, zenith, pow(h, 0.5));
    // below the horizon fade to the horizon colour so the dome never shows a seam
    if (d.z < 0.0) c = horizon * (1.0 + d.z * 0.5);
    float s = max(dot(d, normalize(sunDir)), 0.0);
    c += sunColor * (pow(s, 900.0) * 4.0 + pow(s, 14.0) * 0.28) * sunVisible;
    color = vec4(c, 1.0);
}
