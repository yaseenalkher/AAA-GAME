"""Procedural character animation as pure pose functions.

A pose is a dict joint -> pitch degrees (positive swings a hanging limb FORWARD,
negative spine pitch leans the torso forward), plus 'root_z' (metres) and
'root_p' (whole-body pitch, positive = falls backwards).
"""
import math

JOINTS = ("spine", "head", "shoulderL", "shoulderR", "elbowL", "elbowR",
          "hipL", "hipR", "kneeL", "kneeR")

FACE_EXPRESSIONS = {
    #          brow_tilt(deg), brow_height(m), mouth_w, mouth_h, eye_open
    "calm":      (0.0, 0.0, 1.0, 0.25, 1.0),
    "smile":     (-4.0, 0.004, 1.5, 0.45, 0.85),
    "angry":     (22.0, -0.008, 0.9, 0.18, 0.8),
    "surprised": (-8.0, 0.012, 0.6, 1.2, 1.25),
    "hurt":      (-18.0, 0.0, 1.1, 0.8, 0.45),
}


def _blank():
    p = {j: 0.0 for j in JOINTS}
    p["root_z"] = 0.0
    p["root_p"] = 0.0
    return p


def idle_pose(t):
    p = _blank()
    b = math.sin(t * 1.6)
    p["spine"] = 1.0 * b
    p["head"] = -0.8 * b
    p["shoulderL"] = 2 + 1.5 * b
    p["shoulderR"] = 2 - 1.5 * b
    p["elbowL"] = p["elbowR"] = 6
    p["root_z"] = 0.003 * b
    return p


def locomotion_pose(phase, run_amount):
    """phase in radians (one stride = 2*pi). run_amount 0 (walk) .. 1 (sprint)."""
    p = _blank()
    s = math.sin(phase)
    c = math.cos(phase)
    amp = 28 + 24 * run_amount
    p["hipL"] = amp * s
    p["hipR"] = -amp * s
    knee = 18 + 70 * run_amount
    p["kneeL"] = -knee * max(0.0, c) - 5
    p["kneeR"] = -knee * max(0.0, -c) - 5
    arm = 22 + 38 * run_amount
    p["shoulderL"] = -arm * s
    p["shoulderR"] = arm * s
    elbow_base = 12 + 70 * run_amount
    p["elbowL"] = elbow_base + 10 * max(0.0, s) * run_amount
    p["elbowR"] = elbow_base + 10 * max(0.0, -s) * run_amount
    p["spine"] = -(2 + 14 * run_amount) + 1.5 * math.sin(phase * 2)
    p["head"] = (2 + 8 * run_amount) + 1.0 * math.sin(phase * 2)
    p["root_z"] = -(0.015 + 0.03 * run_amount) * abs(math.sin(phase))
    return p


def jump_pose(vz):
    """vz: vertical velocity; positive = rising."""
    p = _blank()
    rise = max(0.0, min(1.0, 0.5 + vz / 8.0))
    p["hipL"] = 40 + 20 * rise
    p["hipR"] = 10
    p["kneeL"] = -70
    p["kneeR"] = -30
    p["shoulderL"] = p["shoulderR"] = 110 * rise + 20
    p["elbowL"] = p["elbowR"] = 25
    p["spine"] = -4
    return p


def attack_pose(t):
    """Right-hand punch, t in 0..1 (wind-up, strike, recover)."""
    p = locomotion_pose(0.0, 0.0)
    p["hipL"] = p["hipR"] = 0.0
    p["kneeL"] = p["kneeR"] = -8
    if t < 0.3:
        k = t / 0.3
        p["shoulderR"] = -30 * k
        p["elbowR"] = 100 * k
        p["spine"] = 8 * k
    elif t < 0.55:
        k = (t - 0.3) / 0.25
        p["shoulderR"] = -30 + 125 * k
        p["elbowR"] = 100 - 95 * k
        p["spine"] = 8 - 22 * k
    else:
        k = (t - 0.55) / 0.45
        p["shoulderR"] = 95 * (1 - k)
        p["elbowR"] = 5 + 40 * k
        p["spine"] = -14 * (1 - k)
    p["shoulderL"] = 30
    p["elbowL"] = 85
    p["root_z"] = -0.04
    return p


def hit_pose(t):
    p = _blank()
    k = max(0.0, 1 - t / 0.35)
    p["spine"] = 22 * k
    p["head"] = 20 * k
    p["shoulderL"] = p["shoulderR"] = 35 * k
    p["root_z"] = -0.03 * k
    return p


def dead_pose(t):
    p = _blank()
    k = min(1.0, t / 0.6)
    k = 1 - (1 - k) ** 2
    p["root_p"] = 88 * k
    p["root_z"] = 0.22 * k
    p["hipL"] = 8 * k
    p["hipR"] = -6 * k
    p["shoulderL"] = 30 * k
    p["shoulderR"] = 55 * k
    return p


def blend(a, b, w):
    """Linear blend of two poses (w=0 -> a, w=1 -> b)."""
    return {k: a[k] + (b[k] - a[k]) * w for k in a}


def pose_for(state, t, speed=0.0, phase=0.0, vz=0.0, state_t=0.0, run_amount=0.0):
    if state == "idle":
        return idle_pose(t)
    if state == "move":
        w = max(0.0, min(1.0, speed / 1.2))
        return blend(idle_pose(t), locomotion_pose(phase, run_amount), w)
    if state == "air":
        return jump_pose(vz)
    if state == "attack":
        return attack_pose(max(0.0, min(1.0, state_t)))
    if state == "hit":
        return hit_pose(state_t)
    if state == "dead":
        return dead_pose(state_t)
    raise ValueError(state)


def stride_frequency(speed):
    """Stride cycles per second for a given ground speed (m/s)."""
    return 0.55 + 0.26 * speed  # ~1.4 Hz walking, ~2.4 Hz sprinting
