# NEON DISTRICT — Android / Google Play build

Target device: Redmi 14C (8 GB RAM, 256 GB storage), ARM64.
Output: Android App Bundle (`.aab`).

## Current mobile profile

The Android runtime selects the `mobile` preset automatically: 512 shadow map,
no MSAA/bloom/AO, 160 draw distance, 8 NPCs, 4 traffic vehicles, 250 particles
and 256 px generated textures. This is a conservative starting profile, not a
measured FPS guarantee. The on-screen input layer adds a drag joystick plus Jump, Hit, Talk and Camera
buttons (including Run and Pause). Important: Panda3D's standard Android
pointer path has limitations around simultaneous touch. Multi-touch support is
still being discussed/implemented in the upstream project, so do not assume the
joystick and an action button can be held at the same time with the standard
wheel. Test this on the phone before publishing.

## Important Panda3D build prerequisite

Panda3D 1.11's Android pipeline uses Android-specific, cross-compiled Panda3D
wheels. A regular desktop `pip install panda3d` is not enough to produce a valid
Android app. The project now includes the Android-specific requirements file
and a helper to fetch the ARM64 Panda3D wheel. Follow the current official
Android build guide and its linked wheel/toolchain instructions before running
`bdist_apps`:

- https://docs.panda3d.org/1.11/python/distribution/building-for-android
- https://github.com/panda3d/panda3d#android

The official build process currently uses host Python 3.13, Android SDK/NDK,
a recent Panda3D host build and a separate Android ARM64 Panda3D wheel. Do not
replace the Android wheel with a desktop wheel. This project pre-generates and
ships its PNG/WAV assets so the Android runtime does not need NumPy or Pillow;
those packages remain in `requirements.txt` for desktop development/tests.

## Build command (Codespaces terminal)

First install Android command-line tools in the Codespace using Google's
instructions: https://developer.android.com/tools/sdkmanager . Then install
the Android platform/build tools and NDK used by the current Panda3D Android
wheel release:

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"
# After sdkmanager is installed and available on PATH:
sdkmanager --sdk_root="$ANDROID_SDK_ROOT" \
  "platform-tools" "platforms;android-36" "build-tools;36.0.0" \
  "ndk;29.0.14206865"
yes | sdkmanager --sdk_root="$ANDROID_SDK_ROOT" --licenses
```

Then install the Panda3D host build, fetch the matching Android ARM64 wheel and
run the bundle build:

```bash
python3.13 -m pip install --upgrade pip setuptools wheel
python3.13 -m pip install --pre --extra-index-url https://archive.panda3d.org/ panda3d
./scripts/fetch_android_panda_wheel.sh
./scripts/build_android.sh
```

`requirements_android.txt` points `build_apps` at `android-wheels/` and selects
Panda3D's Android wheel. The Android SDK and NDK must already be installed and
configured in Codespaces. Check the official Panda3D guide for the supported
SDK/NDK revisions and any host setup changes before each release.

The generated `.aab` should appear under `dist/`. If no bundle appears, inspect
the full `bdist_apps` log; the most common issue is missing/mismatched Android
Panda3D wheels or SDK/NDK configuration.

## Build from an Android phone only

1. Open GitHub in Chrome and create a private repository named `neon-district`.
2. Upload the contents of this project ZIP (not the ZIP as one file) to the
   repository. Keep `setup_android.py`, `ANDROID_BUILD.md`, and all package
   directories at repository root.
3. Open GitHub Codespaces from the repository menu. Choose a Linux environment.
4. Prepare the Panda3D Android toolchain using the official guide above. This
   includes Android SDK/NDK and Panda3D's Android-specific wheels. The Panda3D
   cross-build can be large and may exceed the resources/time of a small
   Codespace; use a larger Codespace or a dedicated Linux build runner if it
   runs out of memory or time.
5. Run the build command shown above. Download the `.aab` from `dist/` to the
   phone using the Codespaces file browser or upload it as a GitHub Actions
   artifact.
6. Test first with an internal testing track in Google Play Console. An AAB is
   not directly installable like an APK.

## Google Play signing and release

Choose and permanently reserve `com.neondistrict.game` before publishing.
Increment `android_version_code` for every update. For signing, create an upload
certificate/private key using the Panda3D guide, then set `NEON_SIGNING_CERT`
and `NEON_SIGNING_PRIVATE_KEY` to their file paths before running the build.
Optionally set `NEON_SIGNING_PASSPHRASE`. Never commit the private key or its
passphrase to GitHub. Upload the signed AAB to Play Console's internal testing
track before production.

## Validation checklist

- [ ] AAB build completes with the Android Panda3D wheels.
- [ ] App launches on Redmi 14C and stays in landscape mode.
- [ ] Touch movement, jump, attack, talk and camera controls work.
- [ ] Saves/settings can be written and read after app restart.
- [ ] Audio and OpenGL ES renderer initialise without errors.
- [ ] Play internal test reports no install/launch crash.
- [ ] Sustained play test checks heat, memory and frame pacing.

This repository is prepared for the Android packaging stage; an AAB has not
been built or device-tested in this environment. The current touch layer is a
single-pointer prototype, not a confirmed multi-touch implementation. Standard
Panda Android builds have historically used a single mouse-like touch; an
upstream multi-touch PR exists but must be confirmed in the exact wheel before
relying on concurrent joystick + action input.
