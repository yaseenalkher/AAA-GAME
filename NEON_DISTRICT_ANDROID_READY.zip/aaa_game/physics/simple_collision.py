"""Light-weight 2D circle-vs-world collision used by NPCs and traffic checks.

(The player uses the Bullet character controller; NPCs use this to avoid the
cost of hundreds of dynamic bodies.)
"""
import math


def push_out_circle_rect(px, py, r, rect):
    cx = min(max(px, rect.x0), rect.x1)
    cy = min(max(py, rect.y0), rect.y1)
    dx, dy = px - cx, py - cy
    d2 = dx * dx + dy * dy
    if d2 >= r * r:
        return px, py
    if d2 > 1e-12:
        d = math.sqrt(d2)
        k = (r - d) / d
        return px + dx * k, py + dy * k
    # centre is inside the rect: push out along the shallowest axis
    options = [(px - rect.x0, -1, 0), (rect.x1 - px, 1, 0), (py - rect.y0, 0, -1), (rect.y1 - py, 0, 1)]
    dist, nx, ny = min(options, key=lambda o: o[0])
    return px + nx * (dist + r), py + ny * (dist + r)


def push_out_circle_circle(px, py, r, cx, cy, cr):
    dx, dy = px - cx, py - cy
    d = math.hypot(dx, dy)
    mind = r + cr
    if d >= mind:
        return px, py
    if d < 1e-9:
        return px + mind, py
    k = (mind - d) / d
    return px + dx * k, py + dy * k


def make_resolver(rects, circles=(), half_extent=None):
    """Return f(x, y, r) -> (x, y) pushing a circle out of all static geometry."""
    rects = list(rects)
    circles = list(circles)

    def resolve(x, y, r):
        for _ in range(2):
            for rect in rects:
                if rect.x0 - r < x < rect.x1 + r and rect.y0 - r < y < rect.y1 + r:
                    x, y = push_out_circle_rect(x, y, r, rect)
            for cx, cy, cr in circles:
                if abs(cx - x) < r + cr and abs(cy - y) < r + cr:
                    x, y = push_out_circle_circle(x, y, r, cx, cy, cr)
        if half_extent is not None:
            x = max(-half_extent + r, min(half_extent - r, x))
            y = max(-half_extent + r, min(half_extent - r, y))
        return x, y

    return resolve
