"""Panda3D Android App Bundle configuration for NEON DISTRICT.

Build with a Panda3D 1.11 Android-capable build environment and Python 3.13.
See ANDROID_BUILD.md for the Android wheel/toolchain prerequisite.
"""
import os
from setuptools import setup

PRC_DATA = """
load-display pandagles2
aux-display pandagles
window-title NEON DISTRICT
win-size 1280 720
fullscreen 1
sync-video 1
framebuffer-multisample 0
multisamples 0
audio-library-name p3openal_audio
textures-power-2 none
notify-level info
"""

bdist_options = {}
if os.environ.get("NEON_SIGNING_CERT") and os.environ.get("NEON_SIGNING_PRIVATE_KEY"):
    bdist_options = {
        "signing_certificate": os.environ["NEON_SIGNING_CERT"],
        "signing_private_key": os.environ["NEON_SIGNING_PRIVATE_KEY"],
    }
    if os.environ.get("NEON_SIGNING_PASSPHRASE"):
        bdist_options["signing_passphrase"] = os.environ["NEON_SIGNING_PASSPHRASE"]

setup(
    name="neon-district",
    version="1.0.0",
    options={
        "build_apps": {
            "application_id": "com.neondistrict.game",
            "android_version_code": 1,
            "android_min_sdk_version": 23,
            "android_abis": ["arm64-v8a"],
            "platforms": ["android"],
            "requirements_path": "requirements_android.txt",
            "gui_apps": {"neon_district": "main.py"},
            "plugins": ["pandagles2", "pandagles", "p3openal_audio"],
            "include_patterns": [
                "**/*.py", "shaders/*.vert", "shaders/*.frag",
                "assets/**/*", "README.md",
            ],
            "exclude_patterns": [
                "**/__pycache__/**", "**/*.pyc", "tests/**", ".pytest_cache/**",
                "assets/texgen_desktop.py", "audio/synth.py",
            ],
            "extra_prc_data": PRC_DATA,
        },
        "bdist_apps": bdist_options,
    },
    classifiers=["Topic :: Games/Entertainment"],
)
