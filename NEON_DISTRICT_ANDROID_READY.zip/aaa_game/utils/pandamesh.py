"""Bridge from pure Mesh objects to Panda3D nodes, plus small render helpers."""
from panda3d.core import (Geom, GeomNode, GeomTriangles, GeomVertexData, GeomVertexFormat,
                          GeomVertexWriter, LColor, Material, NodePath, Texture)


def mesh_to_nodepath(mesh, name="mesh"):
    vdata = GeomVertexData(name, GeomVertexFormat.getV3n3t2(), Geom.UHStatic)
    vdata.setNumRows(len(mesh.verts))
    vw = GeomVertexWriter(vdata, "vertex")
    nw = GeomVertexWriter(vdata, "normal")
    tw = GeomVertexWriter(vdata, "texcoord")
    for p, n, uv in zip(mesh.verts, mesh.normals, mesh.uvs):
        vw.addData3(*p)
        nw.addData3(*n)
        tw.addData2(*uv)
    prim = GeomTriangles(Geom.UHStatic)
    for a, b, c in mesh.tris:
        prim.addVertices(a, b, c)
    prim.closePrimitive()
    geom = Geom(vdata)
    geom.addPrimitive(prim)
    node = GeomNode(name)
    node.addGeom(geom)
    return NodePath(node)


def set_material(np, color, roughness=0.6, metallic=0.0, emission=None):
    """Attach a PBR-parameterised Material.

    base_color/roughness/metallic are used by PBR pipelines (e.g. panda3d-simplepbr);
    diffuse/ambient/shininess give a sensible look in Panda3D's built-in pipeline.
    """
    c = LColor(color[0], color[1], color[2], 1.0)
    m = Material()
    m.setDiffuse(c)
    m.setAmbient(c)
    m.setSpecular(LColor(0.4, 0.4, 0.4, 1.0) if metallic < 0.5 else LColor(c[0], c[1], c[2], 1.0))
    m.setShininess(max(1.0, (1.0 - roughness) * 90.0))
    if hasattr(m, "setBaseColor"):
        m.setBaseColor(c)
    if hasattr(m, "setRoughness"):
        m.setRoughness(roughness)
    if hasattr(m, "setMetallic"):
        m.setMetallic(metallic)
    if emission is not None:
        m.setEmission(LColor(emission[0], emission[1], emission[2], 1.0))
    np.setMaterial(m, 1)
    return m


def load_tex(loader, path, repeat=True):
    tex = loader.loadTexture(str(path))
    if repeat:
        tex.setWrapU(Texture.WMRepeat)
        tex.setWrapV(Texture.WMRepeat)
    tex.setMinfilter(Texture.FTLinearMipmapLinear)
    tex.setMagfilter(Texture.FTLinear)
    tex.setAnisotropicDegree(8)
    return tex
