"""Pure-Python mesh generation (no engine dependency, unit-testable).

All meshes are z-up. A Mesh stores per-vertex position/normal/uv and triangle
indices (counter-clockwise when seen from outside).
"""
import math
from dataclasses import dataclass, field


@dataclass
class Mesh:
    verts: list = field(default_factory=list)
    normals: list = field(default_factory=list)
    uvs: list = field(default_factory=list)
    tris: list = field(default_factory=list)

    def add_vertex(self, p, n, uv):
        self.verts.append(tuple(p))
        self.normals.append(tuple(n))
        self.uvs.append(tuple(uv))
        return len(self.verts) - 1

    def add_quad(self, a, b, c, d):
        self.tris.append((a, b, c))
        self.tris.append((a, c, d))

    def merge(self, other):
        off = len(self.verts)
        self.verts += other.verts
        self.normals += other.normals
        self.uvs += other.uvs
        self.tris += [(a + off, b + off, c + off) for a, b, c in other.tris]
        return self

    def translated(self, dx=0.0, dy=0.0, dz=0.0):
        m = Mesh(list(self.verts), list(self.normals), list(self.uvs), list(self.tris))
        m.verts = [(x + dx, y + dy, z + dz) for x, y, z in m.verts]
        return m

    def scaled(self, sx=1.0, sy=None, sz=None):
        sy = sx if sy is None else sy
        sz = sx if sz is None else sz
        m = Mesh(list(self.verts), [], list(self.uvs), list(self.tris))
        m.verts = [(x * sx, y * sy, z * sz) for x, y, z in self.verts]
        for nx, ny, nz in self.normals:  # inverse-transpose for non-uniform scale
            v = (nx / sx, ny / sy, nz / sz)
            l = math.sqrt(sum(c * c for c in v)) or 1.0
            m.normals.append((v[0] / l, v[1] / l, v[2] / l))
        return m

    def bounds(self):
        xs, ys, zs = zip(*self.verts)
        return (min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs))

    def validate(self):
        n = len(self.verts)
        assert len(self.normals) == n and len(self.uvs) == n
        for t in self.tris:
            assert all(0 <= i < n for i in t), "triangle index out of range"
        return True


def box(sx, sy, sz, uv_scale=(1.0, 1.0), centered=True):
    """Axis aligned box. If centered=False the base sits at z=0 and is centred in xy."""
    hx, hy, hz = sx / 2, sy / 2, sz / 2
    zc = 0.0 if centered else hz
    m = Mesh()
    faces = [
        ((1, 0, 0), [(hx, -hy, -hz), (hx, hy, -hz), (hx, hy, hz), (hx, -hy, hz)], (sy, sz)),
        ((-1, 0, 0), [(-hx, hy, -hz), (-hx, -hy, -hz), (-hx, -hy, hz), (-hx, hy, hz)], (sy, sz)),
        ((0, 1, 0), [(hx, hy, -hz), (-hx, hy, -hz), (-hx, hy, hz), (hx, hy, hz)], (sx, sz)),
        ((0, -1, 0), [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, -hy, hz), (-hx, -hy, hz)], (sx, sz)),
        ((0, 0, 1), [(-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)], (sx, sy)),
        ((0, 0, -1), [(-hx, hy, -hz), (hx, hy, -hz), (hx, -hy, -hz), (-hx, -hy, -hz)], (sx, sy)),
    ]
    for n, pts, (w, h) in faces:
        uvs = [(0, 0), (w * uv_scale[0], 0), (w * uv_scale[0], h * uv_scale[1]), (0, h * uv_scale[1])]
        ids = [m.add_vertex((p[0], p[1], p[2] + zc), n, uv) for p, uv in zip(pts, uvs)]
        m.add_quad(*ids)
    return m


def plane(w, d, uv_repeat=(1.0, 1.0), z=0.0):
    hw, hd = w / 2, d / 2
    m = Mesh()
    ids = [m.add_vertex((-hw, -hd, z), (0, 0, 1), (0, 0)),
           m.add_vertex((hw, -hd, z), (0, 0, 1), (uv_repeat[0], 0)),
           m.add_vertex((hw, hd, z), (0, 0, 1), uv_repeat),
           m.add_vertex((-hw, hd, z), (0, 0, 1), (0, uv_repeat[1]))]
    m.add_quad(*ids)
    return m


def cylinder(r_bottom, r_top, height, segments=12, caps=True):
    """Z-axis cylinder/cone with base at z=0 and top at z=height."""
    m = Mesh()
    slope = (r_bottom - r_top) / height if height else 0.0
    for i in range(segments + 1):
        a = 2 * math.pi * i / segments
        ca, sa = math.cos(a), math.sin(a)
        l = math.sqrt(1 + slope * slope)
        n = (ca / l, sa / l, slope / l)
        u = i / segments
        m.add_vertex((ca * r_bottom, sa * r_bottom, 0.0), n, (u, 0))
        m.add_vertex((ca * r_top, sa * r_top, height), n, (u, 1))
    for i in range(segments):
        b0, t0, b1, t1 = 2 * i, 2 * i + 1, 2 * i + 2, 2 * i + 3
        m.add_quad(b0, b1, t1, t0)
    if caps:
        for r, z, nz in ((r_bottom, 0.0, -1), (r_top, height, 1)):
            if r <= 1e-6:
                continue
            c = m.add_vertex((0, 0, z), (0, 0, nz), (0.5, 0.5))
            ring = []
            for i in range(segments):
                a = 2 * math.pi * i / segments
                ring.append(m.add_vertex((math.cos(a) * r, math.sin(a) * r, z), (0, 0, nz),
                                         (0.5 + 0.5 * math.cos(a), 0.5 + 0.5 * math.sin(a))))
            for i in range(segments):
                a, b = ring[i], ring[(i + 1) % segments]
                m.tris.append((c, b, a) if nz > 0 else (c, a, b))
    return m


def sphere(radius=0.5, segments=16, rings=10):
    m = Mesh()
    for j in range(rings + 1):
        phi = math.pi * j / rings
        for i in range(segments + 1):
            th = 2 * math.pi * i / segments
            n = (math.sin(phi) * math.cos(th), math.sin(phi) * math.sin(th), math.cos(phi))
            m.add_vertex((n[0] * radius, n[1] * radius, n[2] * radius), n, (i / segments, 1 - j / rings))
    w = segments + 1
    for j in range(rings):
        for i in range(segments):
            a, b = j * w + i, j * w + i + 1
            c, d = (j + 1) * w + i + 1, (j + 1) * w + i
            # outward facing CCW
            if j > 0:
                m.tris.append((a, d, b))
            if j < rings - 1:
                m.tris.append((b, d, c))
    return m


def tapered_limb(r_top, r_bottom, length, segments=10):
    """Limb that hangs down from z=0 to z=-length, with a rounded joint cap on top."""
    body = cylinder(r_bottom, r_top, length, segments, caps=False).translated(0, 0, -length)
    cap = sphere(r_top, segments, 6)
    end = sphere(r_bottom, segments, 6).translated(0, 0, -length)
    return body.merge(cap).merge(end)
