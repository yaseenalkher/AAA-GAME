"""NPC actor: couples a pure NpcBrain with a Humanoid and the animation system."""
import math
import random

from ai.npc_ai import NpcBrain
from animations import procedural as anim
from characters.humanoid import Humanoid, random_appearance


class NpcActor:
    def __init__(self, game, kind, x, y, rng=None, bounds=None):
        self.game = game
        self.rng = rng or random.Random()
        self.brain = NpcBrain(kind, x, y, self.rng, bounds)
        app = random_appearance(self.rng, kind)
        if kind == "guide":
            app.update(shirt=5, pants=1, hair_style="short", face="smile", body="athletic", height=1.80)
        self.body = Humanoid(game.render, app, f"npc_{kind}")
        self.body.root.setPos(x, y, 0)
        self.phase = self.rng.uniform(0, 6.28)
        self.t = self.rng.uniform(0, 10)
        self.state_t = 0.0
        self.anim_state = "idle"
        self.voice = None
        self.voice_timer = self.rng.uniform(4, 14)
        self.removed = False
        self.marker = None
        if kind == "guide":
            self.voice = game.audio.make_voice(self.body.root, "voice2")

    @property
    def kind(self):
        return self.brain.kind

    @property
    def pos(self):
        return (self.brain.x, self.brain.y)

    def update(self, dt, player_xy, player_alive, resolver):
        b = self.brain
        was_stagger = b.stagger > 0
        events = b.step(dt, player_xy, player_alive, resolver)
        self.t += dt

        if not b.alive:
            new = "dead"
        elif b.stagger > 0:
            new = "hit"
        elif b.state == "attack":
            new = "attack"
        elif b.speed > 0.1:
            new = "move"
        else:
            new = "idle"
        if new != self.anim_state:
            self.anim_state = new
            self.state_t = 0.0
            if new == "hit":
                self.body.set_expression("hurt")
        self.state_t += dt

        if new == "attack":
            st = 1.0 - max(0.0, b.attack_timer) / b.p["wind_up"]
        elif new == "hit":
            st = self.state_t
        else:
            st = self.state_t
        if new == "dead":
            st = b.death_timer
        if new == "hit" and not was_stagger:
            pass
        if not b.alive and self.body.expression != "hurt":
            self.body.set_expression("hurt")
        elif b.alive and new != "hit":
            want = {"thug": "angry", "guide": "smile"}.get(b.kind, "surprised" if b.state == "flee" else "calm")
            if self.body.expression != want:
                self.body.set_expression(want)

        run = 1.0 if b.speed > 3.0 else 0.0
        self.phase += anim.stride_frequency(b.speed) * 2 * math.pi * dt
        pose = anim.pose_for(new, self.t, speed=b.speed, phase=self.phase, state_t=st, run_amount=run)
        self.body.apply_pose(pose)
        self.body.root.setPos(b.x, b.y, 0)
        self.body.root.setH(b.heading)

        if self.voice and b.alive:
            self.voice_timer -= dt
            if self.voice_timer <= 0:
                self.voice_timer = self.rng.uniform(8, 20)
                self.voice.play()
        return events

    def destroy(self):
        if self.voice:
            self.game.audio.release_voice(self.voice)
        self.body.destroy()
        self.removed = True
