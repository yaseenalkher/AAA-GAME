"""Procedural stylised humanoid built from smooth primitives with a jointed skeleton.

Honest scope note: these are *stylised low-poly humans* generated in code, not
photoreal scanned characters. To use real character models, load a rigged glTF
with Actor/loader.loadModel and drive the same pose dictionaries (see README).
"""
import random

from panda3d.core import Vec3

import config as C
from animations import procedural as anim
from utils import geometry as geo
from utils.pandamesh import mesh_to_nodepath, set_material

_proto_cache = {}


def _proto(key, factory):
    if key not in _proto_cache:
        _proto_cache[key] = mesh_to_nodepath(factory(), key)
    return _proto_cache[key]


def random_appearance(rng=None, kind="civilian"):
    rng = rng or random.Random()
    a = dict(C.DEFAULT_APPEARANCE)
    a.update(body=rng.choice(list(C.BODY_TYPES)), height=round(rng.uniform(1.58, 1.95) * 50) / 50,
             skin=rng.randrange(len(C.SKIN_TONES)), hair_style=rng.choice(C.HAIR_STYLES),
             hair_color=rng.randrange(len(C.HAIR_COLORS)), shirt=rng.randrange(len(C.CLOTH_COLORS)),
             pants=rng.randrange(len(C.CLOTH_COLORS)), face="calm")
    if kind == "thug":
        a.update(shirt=3, pants=3, face="angry", body=rng.choice(["athletic", "broad"]))
    return a


class Humanoid:
    """Feet-origin character rig. Facing +Y. Use apply_pose() with procedural poses."""

    def __init__(self, parent, appearance, name="human"):
        self.appearance = dict(appearance)
        self.root = parent.attachNewNode(name)
        self.j = {}
        self._brows = []
        self._eyes = []
        self._mouth = None
        self._build()
        self.set_expression(appearance.get("face", "calm"))

    # ------------------------------------------------------------------
    def _part(self, parent, key, factory, color, pos=(0, 0, 0), hpr=(0, 0, 0), rough=0.7, metal=0.0):
        n = _proto(key, factory).copyTo(parent)
        n.setPos(*pos)
        n.setHpr(*hpr)
        n.setColor(color[0], color[1], color[2], 1)
        set_material(n, color, rough, metal)
        return n

    def _joint(self, name, parent, pos):
        n = parent.attachNewNode(name)
        n.setPos(*pos)
        self.j[name] = n
        return n

    def _build(self):
        a = self.appearance
        h = float(a["height"])
        b = C.BODY_TYPES.get(a["body"], 1.0)
        skin = C.SKIN_TONES[a["skin"] % len(C.SKIN_TONES)]
        hair = C.HAIR_COLORS[a["hair_color"] % len(C.HAIR_COLORS)]
        shirt = C.CLOTH_COLORS[a["shirt"] % len(C.CLOTH_COLORS)]
        pants = C.CLOTH_COLORS[a["pants"] % len(C.CLOTH_COLORS)]
        shoes = (0.08, 0.08, 0.09)
        self.height = h

        leg = 0.50 * h
        thigh, shin = 0.26 * h, 0.24 * h
        torso = 0.32 * h
        neck = 0.04 * h
        hr = 0.065 * h
        upper, fore = 0.17 * h, 0.15 * h
        sh_x = 0.115 * h * b
        hip_x = 0.05 * h * b
        key = f"{h:.3f}_{b:.2f}"

        hips = self._joint("hips", self.root, (0, 0, leg))
        self.leg_len = leg
        self._part(hips, f"pelvis_{key}", lambda: geo.sphere(0.075 * h * b, 14, 8).scaled(1.1, 0.7, 0.75),
                   pants, rough=0.9)

        spine = self._joint("spine", hips, (0, 0, 0))
        self._part(spine, f"torso_{key}",
                   lambda: geo.cylinder(0.078 * h * b, 0.10 * h * b, torso, 14).scaled(1, 0.62, 1),
                   shirt, rough=0.9)
        self._part(spine, f"chest_{key}", lambda: geo.sphere(0.10 * h * b, 14, 8).scaled(1.0, 0.62, 0.6),
                   shirt, pos=(0, 0, torso - 0.045 * h), rough=0.9)
        self._part(spine, f"neck_{key}", lambda: geo.cylinder(0.028 * h, 0.026 * h, neck + 0.02 * h, 10),
                   skin, pos=(0, 0, torso - 0.01 * h), rough=0.55)

        head = self._joint("head", spine, (0, 0, torso + neck))
        self._build_head(head, hr, skin, hair, a["hair_style"], key)

        for side, sx in (("L", -1), ("R", 1)):
            sh = self._joint(f"shoulder{side}", spine, (sx * sh_x, 0, torso - 0.03 * h))
            self._part(sh, f"upperarm_{key}", lambda: geo.tapered_limb(0.033 * h * b, 0.028 * h * b, upper),
                       shirt, rough=0.9)
            el = self._joint(f"elbow{side}", sh, (0, 0, -upper))
            self._part(el, f"forearm_{key}", lambda: geo.tapered_limb(0.027 * h, 0.021 * h, fore),
                       skin, rough=0.55)
            self._part(el, f"hand_{key}", lambda: geo.sphere(0.028 * h, 10, 6).scaled(0.8, 1.0, 1.3),
                       skin, pos=(0, 0, -fore - 0.02 * h), rough=0.55)

            hp = self._joint(f"hip{side}", hips, (sx * hip_x, 0, 0))
            self._part(hp, f"thigh_{key}", lambda: geo.tapered_limb(0.052 * h * b, 0.038 * h * b, thigh),
                       pants, rough=0.9)
            kn = self._joint(f"knee{side}", hp, (0, 0, -thigh))
            self._part(kn, f"shin_{key}", lambda: geo.tapered_limb(0.037 * h * b, 0.026 * h * b, shin),
                       pants, rough=0.9)
            self._part(kn, f"shoe_{key}", lambda: geo.box(0.05 * h * 1.1, 0.13 * h, 0.04 * h)
                       .translated(0, 0.03 * h, 0), shoes, pos=(0, 0, -shin - 0.005 * h), rough=0.5)

        self.joints_for_pose = {n: self.j[n] for n in anim.JOINTS}

    def _build_head(self, head, r, skin, hair, style, key):
        cz = r * 0.92
        self._part(head, f"skull_{key}", lambda: geo.sphere(r, 18, 12).scaled(0.82, 0.92, 1.0),
                   skin, pos=(0, 0, cz), rough=0.5)
        self._part(head, f"jaw_{key}", lambda: geo.sphere(r * 0.7, 14, 8).scaled(0.95, 0.9, 0.85),
                   skin, pos=(0, r * 0.12, cz - r * 0.55), rough=0.5)
        for sx in (-1, 1):
            self._part(head, f"ear_{key}", lambda: geo.sphere(r * 0.2, 8, 6).scaled(0.4, 0.8, 1.2),
                       skin, pos=(sx * r * 0.82, 0, cz), rough=0.5)
            white = self._part(head, f"eye_{key}", lambda: geo.sphere(r * 0.15, 10, 8).scaled(1, 0.7, 1),
                               (0.95, 0.95, 0.95), pos=(sx * r * 0.33, r * 0.82, cz + r * 0.1), rough=0.2)
            self._part(white, f"iris_{key}", lambda: geo.sphere(r * 0.085, 8, 6),
                       (0.18, 0.30, 0.45), pos=(0, r * 0.07, 0), rough=0.15)
            self._eyes.append(white)
            brow = self._part(head, f"brow_{key}", lambda: geo.box(r * 0.30, r * 0.06, r * 0.05),
                              hair, pos=(sx * r * 0.33, r * 0.83, cz + r * 0.33), rough=0.9)
            brow.setPythonTag("side", sx)
            self._brows.append((brow, cz + r * 0.33))
        self._part(head, f"nose_{key}", lambda: geo.sphere(r * 0.12, 8, 6).scaled(0.8, 1.2, 1.4),
                   skin, pos=(0, r * 0.9, cz - r * 0.12), rough=0.5)
        self._mouth = self._part(head, f"mouth_{key}", lambda: geo.box(r * 0.34, r * 0.05, r * 0.07),
                                 (0.45, 0.12, 0.12), pos=(0, r * 0.80, cz - r * 0.45), rough=0.4)
        self._head_r, self._cz = r, cz

        def hair_cap():
            return geo.sphere(r * 1.05, 16, 10).scaled(0.88, 1.0, 1.0)
        if style == "short":
            self._part(head, f"hair_short_{key}", hair_cap, hair, pos=(0, -r * 0.2, cz + r * 0.2), rough=0.9)
        elif style == "long":
            self._part(head, f"hair_long_{key}", hair_cap, hair, pos=(0, -r * 0.2, cz + r * 0.2), rough=0.9)
            self._part(head, f"hair_back_{key}", lambda: geo.sphere(r, 12, 8).scaled(0.95, 0.45, 1.9),
                       hair, pos=(0, -r * 0.6, cz - r * 0.8), rough=0.9)
        elif style == "ponytail":
            self._part(head, f"hair_pt_{key}", hair_cap, hair, pos=(0, -r * 0.2, cz + r * 0.2), rough=0.9)
            self._part(head, f"pony_{key}", lambda: geo.tapered_limb(r * 0.22, r * 0.12, r * 2.0),
                       hair, pos=(0, -r * 1.0, cz + r * 0.1), hpr=(0, -20, 0), rough=0.9)

    # ------------------------------------------------------------------
    def set_expression(self, name):
        tilt, height, mw, mh, eye = anim.FACE_EXPRESSIONS.get(name, anim.FACE_EXPRESSIONS["calm"])
        for brow, base_z in self._brows:
            side = brow.getPythonTag("side")
            brow.setR(-side * tilt)
            brow.setZ(base_z + self._head_r * height * 8)
        for e in self._eyes:
            e.setSz(eye * 1.0)
        if self._mouth:
            self._mouth.setScale(mw, 1, mh)
        self.expression = name

    def apply_pose(self, pose):
        for name in anim.JOINTS:
            self.j[name].setP(pose[name])
        self.j["hips"].setZ(self.leg_len + pose["root_z"])
        self.root.setP(pose["root_p"])

    def destroy(self):
        self.root.removeNode()
