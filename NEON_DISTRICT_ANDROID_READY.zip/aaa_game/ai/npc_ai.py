"""NPC brains: pure state machines (no engine dependency).

kinds:
  civilian - wanders, flees when hurt
  thug     - patrols, chases the player when close, attacks in melee
  guide    - stands still, quest giver
"""
import math
import random

TAU = 2 * math.pi


def angle_to(dx, dy):
    """Heading in degrees where 0 faces +Y and positive turns counter-clockwise (Panda H)."""
    return math.degrees(math.atan2(-dx, dy))


class NpcBrain:
    KINDS = {
        "civilian": dict(hp=40, walk=1.4, run=4.5, radius=0.4),
        "thug": dict(hp=60, walk=1.5, run=4.2, radius=0.45, sight=18.0, lose=28.0,
                     attack_range=1.5, attack_damage=8.0, attack_cd=1.2, wind_up=0.35),
        "guide": dict(hp=999, walk=0.0, run=0.0, radius=0.4),
    }

    def __init__(self, kind, x, y, rng=None, bounds=None):
        assert kind in self.KINDS
        p = self.KINDS[kind]
        self.kind = kind
        self.rng = rng or random.Random()
        self.x, self.y = x, y
        self.home = (x, y)
        self.heading = self.rng.uniform(-180, 180)
        self.hp = self.max_hp = p["hp"]
        self.p = p
        self.state = "idle"
        self.timer = self.rng.uniform(0.5, 3.0)
        self.target_pt = None
        self.attack_timer = 0.0
        self.attack_cd = 0.0
        self.stagger = 0.0
        self.speed = 0.0
        self.alive = True
        self.fear = 0.0
        self.bounds = bounds
        self.death_timer = 0.0

    # --------------------------------------------------------------
    @property
    def radius(self):
        return self.p["radius"]

    def take_hit(self, dmg, from_xy):
        if not self.alive or self.kind == "guide":
            return False
        self.hp -= dmg
        self.stagger = 0.35
        dx, dy = self.x - from_xy[0], self.y - from_xy[1]
        d = math.hypot(dx, dy) or 1.0
        self.x += dx / d * 0.5
        self.y += dy / d * 0.5
        if self.hp <= 0:
            self.alive = False
            self.state = "dead"
            self.speed = 0.0
            return True
        if self.kind == "civilian":
            self.state = "flee"
            self.fear = 6.0
        else:
            self.state = "chase"
        return False

    def _pick_wander_point(self, radius=14.0):
        for _ in range(8):
            a = self.rng.uniform(0, TAU)
            d = self.rng.uniform(4, radius)
            tx, ty = self.home[0] + math.cos(a) * d, self.home[1] + math.sin(a) * d
            if self.bounds is None or (abs(tx) < self.bounds and abs(ty) < self.bounds):
                return tx, ty
        return self.home

    def _move_towards(self, tx, ty, speed, dt, turn_rate=360.0):
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)
        if dist < 1e-6:
            return 0.0
        want = angle_to(dx, dy)
        diff = (want - self.heading + 180) % 360 - 180
        step = turn_rate * dt
        self.heading += max(-step, min(step, diff))
        # move along the (now mostly aligned) heading
        rad = math.radians(self.heading)
        mv = min(speed * dt, dist)
        self.x += -math.sin(rad) * mv
        self.y += math.cos(rad) * mv
        self.speed = speed
        return dist

    # --------------------------------------------------------------
    def step(self, dt, player_xy, player_alive=True, resolver=None):
        """Advance the brain. Returns a list of events: ('attack', damage)."""
        events = []
        if not self.alive:
            self.death_timer += dt
            self.speed = 0.0
            return events
        self.attack_cd = max(0.0, self.attack_cd - dt)
        if self.stagger > 0:
            self.stagger -= dt
            self.speed = 0.0
            return events

        px, py = player_xy
        dp = math.hypot(px - self.x, py - self.y)
        self.speed = 0.0

        if self.kind == "guide":
            if dp < 12:
                self._face(px, py, dt)
            self.state = "idle"
        elif self.kind == "civilian":
            self._civilian(dt, px, py, dp)
        else:
            events += self._thug(dt, px, py, dp, player_alive)

        if resolver is not None:
            self.x, self.y = resolver(self.x, self.y, self.radius)
        return events

    def _face(self, px, py, dt):
        want = angle_to(px - self.x, py - self.y)
        diff = (want - self.heading + 180) % 360 - 180
        self.heading += max(-240 * dt, min(240 * dt, diff))

    def _civilian(self, dt, px, py, dp):
        if self.state == "flee":
            self.fear -= dt
            if dp < 25:
                self._move_towards(self.x + (self.x - px), self.y + (self.y - py), self.p["run"], dt)
            if self.fear <= 0:
                self.state = "idle"
                self.timer = 1.0
            return
        self.timer -= dt
        if self.state == "idle":
            if self.timer <= 0:
                self.target_pt = self._pick_wander_point()
                self.state = "wander"
        elif self.state == "wander":
            d = self._move_towards(*self.target_pt, self.p["walk"], dt, 180)
            if d < 0.6:
                self.state = "idle"
                self.timer = self.rng.uniform(2.0, 6.0)

    def _thug(self, dt, px, py, dp, player_alive):
        ev = []
        p = self.p
        if not player_alive:
            self.state = "idle"
            return ev
        if self.state in ("idle", "wander"):
            if dp < p["sight"]:
                self.state = "chase"
            else:
                self.timer -= dt
                if self.state == "idle" and self.timer <= 0:
                    self.target_pt = self._pick_wander_point(10.0)
                    self.state = "wander"
                elif self.state == "wander":
                    if self._move_towards(*self.target_pt, p["walk"], dt, 180) < 0.6:
                        self.state = "idle"
                        self.timer = self.rng.uniform(1.5, 4.0)
        elif self.state == "chase":
            if dp > p["lose"]:
                self.state = "idle"
                self.timer = 1.0
            elif dp <= p["attack_range"]:
                self.state = "attack"
                self.attack_timer = p["wind_up"]
            else:
                self._move_towards(px, py, p["run"], dt, 540)
        elif self.state == "attack":
            self._face(px, py, dt)
            self.attack_timer -= dt
            if self.attack_timer <= 0:
                if dp <= p["attack_range"] + 0.4 and self.attack_cd <= 0:
                    ev.append(("attack", p["attack_damage"]))
                self.attack_cd = p["attack_cd"]
                self.state = "chase"
        return ev
