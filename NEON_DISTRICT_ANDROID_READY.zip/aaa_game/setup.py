"""Desktop package entry point. Use setup_android.py for Google Play builds."""
from setuptools import setup

setup(
    name="neon-district",
    version="1.0.0",
    packages=[
        "ai", "animations", "assets", "audio", "characters", "environments",
        "gameplay", "physics", "player", "save_system", "ui", "utils",
    ],
    install_requires=["panda3d>=1.11.0", "numpy>=1.24", "Pillow>=10.0"],
)
