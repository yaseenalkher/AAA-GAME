#!/usr/bin/env bash
set -euo pipefail
mkdir -p android-wheels
WHEEL="panda3d-1.11.0-cp313-cp313-android_arm64.whl"
URL="https://rdb.name/${WHEEL}"
echo "Downloading Panda3D Android ARM64 wheel..."
curl --fail --location --retry 3 "$URL" --output "android-wheels/$WHEEL"
ls -lh "android-wheels/$WHEEL"
