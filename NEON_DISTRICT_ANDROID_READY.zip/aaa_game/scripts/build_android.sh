#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3.13}"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: Python 3.13 is required by the current Panda3D Android toolchain." >&2
  exit 2
fi
if [[ -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: ANDROID_SDK_ROOT is not set. Install Android SDK/NDK first." >&2
  exit 2
fi
if ! "$PYTHON_BIN" -c 'import panda3d' >/dev/null 2>&1; then
  echo "ERROR: Host Panda3D 1.11 build tools are not installed." >&2
  exit 2
fi

"$PYTHON_BIN" -m pip install --upgrade setuptools wheel
"$PYTHON_BIN" setup_android.py bdist_apps

shopt -s nullglob
bundles=(dist/*.aab)
if (( ${#bundles[@]} == 0 )); then
  echo "ERROR: build finished without an AAB. Review the bdist_apps log and verify Android-specific Panda3D wheels." >&2
  exit 3
fi
printf 'AAB created:\n'
printf ' - %s\n' "${bundles[@]}"
