"""Generate bundled game textures and WAV assets on a desktop Python setup."""
from config import GENERATED
from assets.texgen_desktop import ensure_textures
from audio.synth import ensure_audio

if __name__ == "__main__":
    textures = ensure_textures(GENERATED / "textures", size=512)
    audio = ensure_audio(GENERATED / "audio")
    print(f"Generated/verified {len(textures)} textures and {len(audio)} sounds.")
