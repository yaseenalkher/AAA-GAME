"""NEON DISTRICT - open-world 3D action game (Python + Panda3D).

Run:  python main.py            (see README.md for installation)
"""
import math
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from panda3d.core import loadPrcFileData  # noqa: E402

import config as C  # noqa: E402
from save_system.save_manager import SaveManager  # noqa: E402

SAVES = SaveManager()
IS_ANDROID = (sys.platform == "android" or "ANDROID_ARGUMENT" in os.environ)
SETTINGS = SAVES.load_settings()
if IS_ANDROID:
    SETTINGS["quality"] = "mobile"
    SETTINGS["fullscreen"] = True
_q = C.QUALITY_PRESETS[SETTINGS["quality"]]
loadPrcFileData("", f"""
window-title {C.GAME_TITLE}
win-size {C.WINDOW_SIZE[0]} {C.WINDOW_SIZE[1]}
fullscreen {int(SETTINGS['fullscreen'])}
sync-video 1
framebuffer-multisample {1 if _q['msaa'] else 0}
multisamples {_q['msaa']}
audio-library-name p3openal_audio
textures-power-2 none
""")

from direct.showbase.ShowBase import ShowBase  # noqa: E402
from panda3d.bullet import BulletWorld  # noqa: E402
from panda3d.core import (AntialiasAttrib, ClockObject, ModifierButtons, Vec3,  # noqa: E402
                          WindowProperties)

from animations import procedural as anim  # noqa: E402
from audio.audio_manager import AudioManager  # noqa: E402
from characters.humanoid import Humanoid  # noqa: E402
from characters.npc import NpcActor  # noqa: E402
from environments.layout import CityLayout  # noqa: E402
from environments.world import World  # noqa: E402
from gameplay.quests import QuestManager  # noqa: E402
from physics.simple_collision import make_resolver  # noqa: E402
from player.controller import Player  # noqa: E402
from ui.screens import UI  # noqa: E402
from ui.mobile_controls import MobileControls  # noqa: E402
from utils import geometry as geo  # noqa: E402
from utils.pandamesh import mesh_to_nodepath, set_material  # noqa: E402

STAGE = Vec3(4000, 4000, 0)   # character-preview stage, far from the city
GUIDE_LINES = [
    "Welcome to Neon District! Grab the coins scattered around town.",
    "Thugs have been harassing locals. Punch them with the left mouse button.",
    "Come back when you're done - the beacon in the park marks the exit.",
]


class Game(ShowBase):
    def __init__(self):
        super().__init__()
        self.settings = SETTINGS
        self.saves = SAVES
        self.clock_obj = ClockObject.getGlobalClock()
        self.disableMouse()
        self.buttonThrowers[0].node().setModifierButtons(ModifierButtons())
        self.camLens.setNearFar(0.15, 2600)
        self.setBackgroundColor(0.5, 0.6, 0.8, 1)

        self.bullet = BulletWorld()
        self.bullet.setGravity(Vec3(0, 0, -9.81))
        self.layout = CityLayout(seed=7)
        self.layout.beacon = (0.0, 0.0)
        self.resolver = make_resolver(self.layout.colliders, self.layout.tree_colliders,
                                      self.layout.half_extent + 100)

        self.audio = AudioManager(self, self.settings)
        self.render.setShaderAuto()
        self.render.setAntialias(AntialiasAttrib.MAuto)
        self.filters = None
        self.world = World(self, self.bullet, self.layout, self.settings["quality"])
        self.setup_filters()
        self.ui = UI(self)
        self.mobile_controls = MobileControls(self) if IS_ANDROID else None

        self.appearance = dict(C.DEFAULT_APPEARANCE)
        self.preview = None
        self.stage_np = None
        self.state = "title"
        self.settings_origin = "menu"
        self.keys = dict(forward=False, back=False, left=False, right=False, sprint=False)
        self.orbit = 0.0
        self.player = None
        self.quests = None
        self.npcs = []
        self.coins = []
        self.guide = None
        self.rng = random.Random()
        self.thug_timer = 0.0
        self.level_busy = False
        self._skip_mouse = 0
        self.rng_lines = 0
        self._bind_keys()
        self.apply_settings()
        self.taskMgr.add(self.update, "update")
        self.go_title()

    # ---------------------------------------------------------------- setup
    def setup_filters(self):
        q = C.QUALITY_PRESETS[self.settings["quality"]]
        try:
            from direct.filter.CommonFilters import CommonFilters
            if self.filters:
                self.filters.cleanup()
                self.filters = None
            if q["bloom"] or q["ao"]:
                self.filters = CommonFilters(self.win, self.cam)
                if q["bloom"]:
                    self.filters.setBloom(blend=(0.3, 0.4, 0.3, 0.0), mintrigger=0.72, maxtrigger=1.0,
                                          desat=0.6, intensity=0.7, size="medium")
                if q["ao"]:
                    self.filters.setAmbientOcclusion()
        except Exception as e:
            print("[render] post-processing unavailable:", e)
            self.filters = None

    def apply_settings(self, restart_needed=False):
        s = self.settings
        self.audio.apply_settings(s)
        self.camLens.setFov(s["fov"])
        self.setFrameRateMeter(bool(s["show_fps"]))
        props = WindowProperties()
        props.setFullscreen(bool(s["fullscreen"]))
        if s["fullscreen"]:
            props.setSize(self.pipe.getDisplayWidth(), self.pipe.getDisplayHeight())
        else:
            props.setSize(*C.WINDOW_SIZE)
        if props.getFullscreen() != self.win.getProperties().getFullscreen():
            self.win.requestProperties(props)
        if restart_needed:
            self.world.apply_quality(s["quality"])
            self.setup_filters()
        self.saves.save_settings(s)

    def _bind_keys(self):
        K = C.KEYS
        for name in ("forward", "back", "left", "right", "sprint"):
            self.accept(K[name], self._set_key, [name, True])
            self.accept(K[name] + "-up", self._set_key, [name, False])
        self.accept(K["jump"], self._press, ["jump_pressed"])
        self.accept(K["attack"], self._press, ["attack_pressed"])
        self.accept(K["interact"], self.interact)
        self.accept(K["camera"], self._toggle_camera)
        self.accept(K["pause"], self.on_escape)
        self.accept(K["save"], self.save_game)
        self.accept(K["rain"], self._cycle_weather)
        self.accept(K["time"], lambda: self.world.set_hour(self.world.hour + 3))

    def _set_key(self, name, v):
        self.keys[name] = v

    def _press(self, name):
        if self.state == "playing":
            self.keys[name] = True

    def _toggle_camera(self):
        if self.state == "playing" and self.player:
            self.player.toggle_camera()

    def _cycle_weather(self):
        if self.state == "playing":
            states = self.world.weather.STATES
            self.world.weather.force(states[(states.index(self.world.weather.state) + 1) % len(states)])
            self.ui.notify(f"Weather: {self.world.weather.state}", 1.5)

    def capture_mouse(self, on):
        if IS_ANDROID:
            return
        props = WindowProperties()
        props.setCursorHidden(on)
        props.setMouseMode(WindowProperties.M_confined if on else WindowProperties.M_absolute)
        self.win.requestProperties(props)
        self._skip_mouse = 3

    # ---------------------------------------------------------------- screens
    def go_title(self):
        self.state = "title"
        self.capture_mouse(False)
        if self.mobile_controls:
            self.mobile_controls.hide()
        self.ui.show("title")
        self.audio.start_music()
        self.audio.set_loop_volume("wind", 0.3)
        self.audio.set_loop_volume("traffic", 0.15)

    def go_main_menu(self):
        self.clear_stage()
        self.state = "menu"
        self.ui.refresh_menu()
        if self.mobile_controls:
            self.mobile_controls.hide()
        self.ui.show("menu")

    def new_game_character(self):
        self.state = "charselect"
        self.world.set_hour(12)
        self.stage_np = self.render.attachNewNode("stage")
        self.stage_np.setPos(STAGE)
        plat = mesh_to_nodepath(geo.cylinder(2.5, 2.5, 0.15, 36), "platform")
        plat.reparentTo(self.stage_np)
        plat.setColor(0.12, 0.14, 0.2, 1)
        set_material(plat, (0.12, 0.14, 0.2), 0.3, 0.6)
        plat.setZ(-0.15)
        self.appearance = dict(C.DEFAULT_APPEARANCE)
        self.ui.refresh_character()
        self.refresh_preview()
        self.ui.show("character")

    def refresh_preview(self):
        if self.preview:
            self.preview.destroy()
        self.preview = Humanoid(self.stage_np, self.appearance, "preview")
        self.preview.set_expression(self.appearance["face"])
        self.preview.apply_pose(anim.idle_pose(0))

    def clear_stage(self):
        if self.preview:
            self.preview.destroy()
            self.preview = None
        if self.stage_np:
            self.stage_np.removeNode()
            self.stage_np = None

    def go_settings(self, origin):
        self.settings_origin = origin
        self.state = "settings"
        self.ui.show("settings")

    def settings_back(self):
        self.saves.save_settings(self.settings)
        if self.settings_origin == "pause":
            self.state = "paused"
            self.ui.show("pause")
        else:
            self.go_main_menu()

    def quit(self):
        self.saves.save_settings(self.settings)
        self.userExit()

    # ---------------------------------------------------------------- sessions
    def begin_new_game(self):
        def go():
            self.clear_stage()
            self.start_session(None)
        self.ui.fade(go)

    def continue_game(self):
        slot = self.saves.latest_slot()
        data = self.saves.load_game(slot) if slot is not None else None
        if not data:
            self.ui.notify("No save found")
            return

        def go():
            self.clear_stage()
            self.start_session(data)
        self.ui.fade(go)

    def start_session(self, data):
        self.cleanup_session()
        self.quests = QuestManager()
        pos = self.layout.spawn_point
        heading, health, stamina = 0.0, C.PLAYER["max_health"], C.PLAYER["max_stamina"]
        if data:
            self.appearance = dict(C.DEFAULT_APPEARANCE, **data.get("appearance", {}))
            self.quests.load_dict(data.get("quests", {}))
            p = data.get("player", {})
            pos = (p.get("x", pos[0]), p.get("y", pos[1]))
            heading, health = p.get("heading", 0.0), p.get("health", health)
            self.world.set_hour(data.get("hour", C.START_HOUR))
        else:
            self.world.set_hour(C.START_HOUR)
        if not self.layout.is_free(pos[0], pos[1], 0.5):
            pos = self.layout.spawn_point
        self.player = Player(self, self.appearance, pos, heading)
        self.player.health = max(1.0, min(C.PLAYER["max_health"], health))
        self.spawn_population()
        self.fill_coins()
        self.level_busy = False
        self.keys.update(forward=False, back=False, left=False, right=False, sprint=False)
        self.state = "playing"
        self.ui.show("hud")
        if self.mobile_controls:
            self.mobile_controls.show()
        self.capture_mouse(not IS_ANDROID)
        self.audio.set_loop_volume("wind", 0.25)
        self.audio.set_loop_volume("traffic", 0.12)
        self.ui.notify(self.quests.level.name, 2.5)
        self.ui.notify(self.quests.level.intro, 3.5)
        if not data:
            self.save_game(silent=True)

    def cleanup_session(self):
        for n in self.npcs:
            n.destroy()
        self.npcs = []
        self.guide = None
        for c in self.coins:
            c["np"].removeNode()
        self.coins = []
        if self.player:
            self.player.destroy()
            self.player = None

    def spawn_population(self):
        q = C.QUALITY_PRESETS[self.settings["quality"]]
        spawn = self.layout.spawn_point
        lim = self.layout.half_extent
        gx, gy = 5.0, 4.0
        if not self.layout.is_free(gx, gy, 0.8):
            gx, gy = self.layout.random_free_point(self.rng, 0.8)
        self.guide = NpcActor(self, "guide", gx, gy, self.rng, lim)
        self.npcs.append(self.guide)
        n_thug = 8
        n_civ = max(4, q["npcs"] - n_thug)
        for kind, n in (("thug", n_thug), ("civilian", n_civ)):
            for _ in range(n):
                x, y = self.layout.random_free_point(self.rng, 0.8, spawn, 18)
                self.npcs.append(NpcActor(self, kind, x, y, self.rng, lim))

    def fill_coins(self):
        need = sum(o.target - o.progress for o in self.quests.level.objectives if o.kind == "coin")
        want = need + 4 if need > 0 else 0
        while len(self.coins) < want:
            x, y = self.layout.random_free_point(self.rng, 0.8)
            np = mesh_to_nodepath(geo.cylinder(0.32, 0.32, 0.07, 16), "coin")
            np.reparentTo(self.render)
            np.setPos(x, y, 1.0)
            np.setP(90)
            np.setColor(1.0, 0.8, 0.15, 1)
            set_material(np, (1.0, 0.8, 0.15), 0.25, 1.0, emission=(0.35, 0.25, 0.0))
            self.coins.append(dict(np=np, x=x, y=y))

    # ---------------------------------------------------------------- pause / end
    def on_escape(self):
        if self.state == "playing":
            self.state = "paused"
            self.capture_mouse(False)
            self.ui.pause_msg["text"] = ""
            self.ui.show("pause")
        elif self.state == "paused":
            self.resume()
        elif self.state == "settings":
            self.settings_back()

    def resume(self):
        self.keys.update(forward=False, back=False, left=False, right=False, sprint=False)
        self.state = "playing"
        self.ui.show("hud")
        if self.mobile_controls:
            self.mobile_controls.show()
        self.capture_mouse(not IS_ANDROID)

    def exit_to_menu(self):
        def go():
            self.cleanup_session()
            self.go_main_menu()
        self.ui.fade(go)

    def retry(self):
        self.player.revive(self.layout.spawn_point)
        for n in self.npcs:
            if n.kind == "thug":
                n.brain.state = "idle"
        self.state = "playing"
        self.ui.show("hud")
        if self.mobile_controls:
            self.mobile_controls.show()
        self.capture_mouse(not IS_ANDROID)

    def save_game(self, silent=False):
        if not self.player or not self.quests or self.state not in ("playing", "paused"):
            return
        x, y = self.player.xy
        self.saves.save_game(0, dict(
            appearance=self.appearance, quests=self.quests.to_dict(), hour=self.world.hour,
            player=dict(x=x, y=y, health=self.player.health, heading=self.player.heading)))
        if not silent:
            self.ui.notify("Game saved", 1.5)
            self.ui.pause_msg["text"] = "Game saved."

    # ---------------------------------------------------------------- gameplay events
    def interact(self):
        if self.state != "playing" or not self.guide or not self.player.alive:
            return
        px, py = self.player.xy
        gx, gy = self.guide.pos
        if math.hypot(px - gx, py - gy) < 3.2:
            self.ui.notify(GUIDE_LINES[self.rng_lines % len(GUIDE_LINES)], 3.5)
            self.rng_lines += 1
            if self.guide.voice:
                self.guide.voice.play()
            if self.quests.notify("talk"):
                self.audio.play("pickup", 0.8)

    def on_enemy_defeated(self, npc):
        self.quests.notify("enemy")
        self.ui.notify("Thug defeated!  +50", 1.2)
        self.audio.play("pickup", 0.6, 0.7)

    def _check_level(self):
        q = self.quests
        if self.level_busy or not q.level_complete:
            return
        self.level_busy = True
        self.audio.play("win", 0.8)
        if q.advance():
            self.player.heal(40)
            self.ui.notify("LEVEL COMPLETE!", 2.0)
            self.ui.notify(f"Next: {q.level.name}", 2.5)
            self.ui.notify(q.level.intro, 3.5)
            self.fill_coins()
            self.save_game(silent=True)
            self.taskMgr.doMethodLater(3.0, lambda t: setattr(self, "level_busy", False), "levelbusy")
        else:
            self.state = "win"
            self.capture_mouse(False)
            self.ui.win_stats["text"] = f"Score: {q.score}    Coins: {q.coins}    Defeated: {q.kills}"
            self.ui.show("win")

    # ---------------------------------------------------------------- main loop
    def update(self, task):
        from direct.task import Task
        dt = min(self.clock_obj.getDt(), 0.05)
        self.ui.tick(dt)
        if self.mobile_controls:
            if self.state == "playing":
                self.mobile_controls.show()
            else:
                self.mobile_controls.hide()

        if self.state in ("title", "menu", "settings"):
            self.orbit += dt * 4.0
            a = math.radians(self.orbit)
            cp = Vec3(math.cos(a) * 95, math.sin(a) * 95, 42)
            self.camera.setPos(cp)
            self.camera.lookAt(0, 0, 12)
            self.world.update(dt, Vec3(0, 0, 0), cp)
        elif self.state == "charselect":
            self.camera.setPos(STAGE + Vec3(0, -5.2, 1.5))
            self.camera.lookAt(STAGE + Vec3(0, 0, 1.0))
            if self.preview:
                self.preview.root.setH(self.preview.root.getH() + dt * 25)
            self.world.update(dt, STAGE, self.camera.getPos())
        elif self.state == "playing":
            self._play(dt)
        elif self.state in ("paused", "win", "lose") and self.player:
            self.world.update(0.0, self.player.np.getPos(), self.camera.getPos())
        return Task.cont

    def _mouse_delta(self):
        if not self.mouseWatcherNode.hasMouse() or self._skip_mouse > 0:
            if self._skip_mouse > 0:
                self._skip_mouse -= 1
                cx, cy = self.win.getXSize() // 2, self.win.getYSize() // 2
                self.win.movePointer(0, cx, cy)
            return (0.0, 0.0)
        md = self.win.getPointer(0)
        cx, cy = self.win.getXSize() // 2, self.win.getYSize() // 2
        dx, dy = md.getX() - cx, md.getY() - cy
        self.win.movePointer(0, cx, cy)
        return (dx, dy)

    def _play(self, dt):
        p, w = self.player, self.world
        self.bullet.doPhysics(dt, 5, 1.0 / 180.0)
        p.update(dt, self.keys, (0.0, 0.0) if IS_ANDROID else self._mouse_delta(), self.npcs, self.settings)
        px, py = p.xy

        # NPCs
        for npc in list(self.npcs):
            for ev in npc.update(dt, (px, py), p.alive, self.resolver):
                if ev[0] == "attack":
                    p.take_damage(ev[1])
            if npc.brain.death_timer > 5.0:
                npc.destroy()
                self.npcs.remove(npc)
        self.thug_timer -= dt
        if self.thug_timer <= 0:
            self.thug_timer = 8.0
            if sum(1 for n in self.npcs if n.kind == "thug" and n.brain.alive) < 8:
                x, y = self.layout.random_free_point(self.rng, 0.8, (px, py), 35)
                self.npcs.append(NpcActor(self, "thug", x, y, self.rng, self.layout.half_extent))

        # coins
        for c in list(self.coins):
            c["np"].setH(c["np"].getH() + 140 * dt)
            c["np"].setZ(1.0 + 0.1 * math.sin(self.clock_obj.getFrameTime() * 3 + c["x"]))
            if p.alive and (c["x"] - px) ** 2 + (c["y"] - py) ** 2 < 1.4 ** 2:
                c["np"].removeNode()
                self.coins.remove(c)
                self.audio.play("pickup", 0.7, random.uniform(0.95, 1.15))
                self.quests.notify("coin")
                self.ui.notify("+10", 0.6)
        self.fill_coins()

        # traffic damage and beacon
        if p.alive and w.traffic_hit(px, py, 0.4):
            p.take_damage(12)
        if self.quests.needs("reach") and math.hypot(px - self.layout.beacon[0], py - self.layout.beacon[1]) < 4.0:
            self.quests.notify("reach")
            self.audio.play("pickup", 0.8)

        # prompt
        prompt = ""
        if self.guide and math.hypot(px - self.guide.pos[0], py - self.guide.pos[1]) < 3.2:
            prompt = "[E] Talk"

        # world + ambience
        w.update(dt, p.np.getPos(), self.camera.getPos())
        self.audio.set_loop_volume("rain", w.weather.rain * 0.9)
        self.audio.set_loop_volume("wind", 0.2 + 0.4 * max(w.weather.rain, w.weather.fog))
        self.ui.update_hud(p, self.quests, w.hour, prompt,
                           w.weather.state if w.weather.state != "clear" else "")

        self._check_level()
        if not p.alive and p.death_t > 1.8:
            self.state = "lose"
            self.capture_mouse(False)
            self.audio.play("lose", 0.8)
            self.ui.lose_stats["text"] = f"Score: {self.quests.score}"
            self.ui.show("lose")


def main():
    Game().run()


if __name__ == "__main__":
    main()
