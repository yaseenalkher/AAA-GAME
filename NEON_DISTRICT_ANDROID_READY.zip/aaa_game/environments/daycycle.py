"""Day/night colour curves and weather state machine (pure Python)."""
import math
import random

# hour -> (sky RGB, sun/moon colour RGB, ambient RGB, sun strength)
_KEYS = [
    (0.0, (0.02, 0.03, 0.08), (0.20, 0.25, 0.45), (0.10, 0.12, 0.22), 0.25),
    (5.0, (0.05, 0.06, 0.14), (0.25, 0.28, 0.48), (0.10, 0.12, 0.22), 0.25),
    (6.5, (0.95, 0.55, 0.35), (1.00, 0.60, 0.35), (0.35, 0.30, 0.35), 0.7),
    (9.0, (0.45, 0.70, 0.95), (1.00, 0.95, 0.85), (0.42, 0.46, 0.55), 1.0),
    (13.0, (0.40, 0.68, 0.98), (1.00, 0.98, 0.92), (0.46, 0.50, 0.58), 1.1),
    (17.0, (0.50, 0.65, 0.90), (1.00, 0.88, 0.70), (0.42, 0.44, 0.52), 1.0),
    (19.0, (0.90, 0.45, 0.30), (1.00, 0.50, 0.25), (0.32, 0.27, 0.34), 0.65),
    (20.5, (0.06, 0.07, 0.18), (0.25, 0.28, 0.48), (0.12, 0.13, 0.24), 0.3),
    (24.0, (0.02, 0.03, 0.08), (0.20, 0.25, 0.45), (0.10, 0.12, 0.22), 0.25),
]


def _lerp(a, b, t):
    return a + (b - a) * t


def _lerp3(a, b, t):
    return tuple(_lerp(x, y, t) for x, y in zip(a, b))


def sample(hour):
    hour %= 24.0
    for (h0, *v0), (h1, *v1) in zip(_KEYS, _KEYS[1:]):
        if h0 <= hour <= h1:
            t = (hour - h0) / (h1 - h0)
            t = t * t * (3 - 2 * t)
            return dict(sky=_lerp3(v0[0], v1[0], t), sun=_lerp3(v0[1], v1[1], t),
                        ambient=_lerp3(v0[2], v1[2], t), strength=_lerp(v0[3], v1[3], t))
    raise ValueError(hour)


def is_night(hour):
    hour %= 24.0
    return hour < 5.5 or hour > 20.0


def star_alpha(hour):
    hour %= 24.0
    if 6.5 <= hour <= 19.0:
        return 0.0
    if hour > 20.5 or hour < 5.0:
        return 1.0
    if hour > 19.0:
        return (hour - 19.0) / 1.5
    return (6.5 - hour) / 1.5


def sun_direction(hour):
    """Unit vector pointing FROM the world TOWARDS the sun/moon (z-up)."""
    day = 6.0 <= hour % 24 <= 18.0
    h = hour % 24
    ang = (h - 6.0) / 12.0 * math.pi if day else ((h - 18.0) % 24.0) / 12.0 * math.pi
    return (math.cos(ang) * 0.95, 0.3, max(0.05, math.sin(ang)))  # never fully below horizon for light


def lighting_from_hour(hour):
    d = sample(hour)
    return d


class WeatherSystem:
    STATES = ("clear", "cloudy", "rain", "fog")

    def __init__(self, seed=1, min_hold=60.0, max_hold=150.0):
        self.rng = random.Random(seed)
        self.state = "clear"
        self.min_hold, self.max_hold = min_hold, max_hold
        self.timer = self.rng.uniform(min_hold, max_hold)
        self.rain = 0.0     # 0..1 smooth intensity
        self.fog = 0.0
        self.cloud = 0.2

    def target(self):
        return dict(clear=(0.0, 0.0, 0.15), cloudy=(0.0, 0.1, 0.7),
                    rain=(1.0, 0.25, 0.9), fog=(0.0, 1.0, 0.6))[self.state]

    def force(self, state):
        assert state in self.STATES
        self.state = state
        self.timer = self.rng.uniform(self.min_hold, self.max_hold)

    def update(self, dt):
        self.timer -= dt
        if self.timer <= 0:
            weights = {"clear": 4, "cloudy": 3, "rain": 2, "fog": 1}
            choices = [s for s in self.STATES if s != self.state]
            self.force(self.rng.choices(choices, [weights[c] for c in choices])[0])
        r, f, c = self.target()
        k = min(1.0, dt * 0.25)
        self.rain += (r - self.rain) * k
        self.fog += (f - self.fog) * k
        self.cloud += (c - self.cloud) * k
        return self.rain, self.fog, self.cloud
