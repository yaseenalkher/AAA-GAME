"""3D world: ground, roads, buildings, trees, cars, sky, lighting, weather, LOD/culling."""
import math
import random

from panda3d.bullet import (BulletBoxShape, BulletCylinderShape, BulletPlaneShape,
                            BulletRigidBodyNode, ZUp)
from panda3d.core import (AmbientLight, BitMask32, DirectionalLight, Fog, Geom, GeomNode,
                          GeomPoints, GeomVertexData, GeomVertexFormat, GeomVertexWriter,
                          LineSegs, Shader, TextureStage, TransparencyAttrib, Vec3, Vec4)

import config as C
from assets.texgen import ensure_textures
from environments import daycycle
from utils import geometry as geo
from utils.pandamesh import load_tex, mesh_to_nodepath, set_material

CAR_COLORS = [(0.75, 0.1, 0.1), (0.1, 0.25, 0.65), (0.85, 0.85, 0.85), (0.08, 0.08, 0.1),
              (0.9, 0.7, 0.1), (0.15, 0.5, 0.3)]


class World:
    def __init__(self, base, bullet_world, layout, quality):
        self.base = base
        self.bw = bullet_world
        self.layout = layout
        self.q = C.QUALITY_PRESETS[quality]
        self.root = base.render.attachNewNode("world")
        self.hour = C.START_HOUR
        self.time_scale = 1.0
        self.weather = daycycle.WeatherSystem(seed=3)
        self.rng = random.Random(99)
        self.cull_items = []     # (nodepath, x, y, radius, kind[, extra])
        self.traffic = []
        self._cull_timer = 0.0
        self._rain_t = 0.0

        paths = ensure_textures(C.GENERATED / "textures", size=self.q["texture_size"])
        self.tex = {name: load_tex(base.loader, p) for name, p in paths.items()}
        self.glow = {s: load_tex(base.loader, C.GENERATED / "textures" / f"facade{s}_e.png") for s in range(3)}

        self._build_ground()
        self._build_roads()
        self._build_buildings()
        self._build_trees()
        self._build_lamps()
        self._build_cars()
        self._build_beacon()
        self._build_boundary()
        self._build_sky()
        self._build_lights()
        self._build_rain()
        self.update(0.0, Vec3(0, 0, 0))

    # ---------------------------------------------------------------- physics
    def _static_box(self, name, pos, half):
        n = BulletRigidBodyNode(name)
        n.addShape(BulletBoxShape(Vec3(*half)))
        n.setMass(0)
        np = self.root.attachNewNode(n)
        np.setPos(*pos)
        np.setCollideMask(BitMask32.bit(0))
        self.bw.attachRigidBody(n)
        return np

    def _static_cylinder(self, name, x, y, r, h):
        n = BulletRigidBodyNode(name)
        n.addShape(BulletCylinderShape(r, h, ZUp))
        n.setMass(0)
        np = self.root.attachNewNode(n)
        np.setPos(x, y, h / 2)
        np.setCollideMask(BitMask32.bit(0))
        self.bw.attachRigidBody(n)

    # ---------------------------------------------------------------- build
    def _textured(self, mesh, name, tex, color=(1, 1, 1), parent=None):
        np = mesh_to_nodepath(mesh, name)
        np.reparentTo(parent or self.root)
        if tex is not None:
            np.setTexture(tex, 1)
        np.setColor(color[0], color[1], color[2], 1)
        return np

    def _build_ground(self):
        g = self._textured(geo.plane(3000, 3000, (600, 600)), "grass", self.tex["grass"])
        g.setZ(-0.02)
        n = BulletRigidBodyNode("ground")
        n.addShape(BulletPlaneShape(Vec3(0, 0, 1), 0))
        gp = self.root.attachNewNode(n)
        gp.setCollideMask(BitMask32.bit(0))
        self.bw.attachRigidBody(n)

    def _build_roads(self):
        L = self.layout
        he = L.half_extent
        roads = self.root.attachNewNode("roads")
        for i, line in enumerate(L.road_lines):
            # along Y
            m = geo.plane(L.rw, 2 * he + L.rw, (1, (2 * he + L.rw) / 8.0))
            r = self._textured(m, "road_y", self.tex["road"], parent=roads)
            r.setPos(line, 0, 0.02)
            # along X (rotated). Slightly higher so the intersection shows one road's markings only
            r2 = self._textured(m, "road_x", self.tex["road"], parent=roads)
            r2.setPos(0, line, 0.03)
            r2.setH(90)
        for rect in L.block_rects:
            m = geo.plane(L.bs, L.bs, (L.bs / 6.0, L.bs / 6.0))
            b = self._textured(m, "walk", self.tex["pavement"], parent=roads)
            b.setPos(rect.cx, rect.cy, 0.025)
        # the park block is grass
        pr = L.park_rect
        park = self._textured(geo.plane(L.bs, L.bs, (L.bs / 4.0, L.bs / 4.0)), "park", self.tex["grass"], parent=roads)
        park.setPos(pr.cx, pr.cy, 0.04)
        roads.flattenStrong()

    def _build_buildings(self):
        L = self.layout
        ts = TextureStage("glow")
        ts.setMode(TextureStage.MGlow)
        by_block = {}
        for b in L.buildings:
            for i, r in enumerate(L.block_rects):
                if r.contains(b.rect.cx, b.rect.cy):
                    by_block.setdefault(i, []).append(b)
                    break
        tints = [(1.0, 0.95, 0.9), (0.9, 0.95, 1.0), (1.0, 1.0, 1.0)]
        for i, blds in by_block.items():
            bn = self.root.attachNewNode(f"block{i}")
            for b in blds:
                r = b.rect
                m = geo.box(r.w, r.d, b.height, (1 / 12.0, 1 / 12.0), centered=False)
                np = self._textured(m, "building", self.tex[f"facade{b.style}"],
                                    tints[self.rng.randrange(3)], bn)
                np.setTexture(ts, self.glow[b.style])
                np.setPos(r.cx, r.cy, 0)
                self._static_box("bld", (r.cx, r.cy, b.height / 2), (r.w / 2, r.d / 2, b.height / 2))
            bn.flattenStrong()
            rect = L.block_rects[i]
            self.cull_items.append((bn, rect.cx, rect.cy, L.bs * 0.8, "block"))

    def _build_trees(self):
        trunk = self._textured(geo.cylinder(0.22, 0.14, 2.8, 8), "trunk", self.tex["bark"])
        hi = self.root.attachNewNode("tree_hi_proto")
        trunk.reparentTo(hi)
        for (r, z, ox, oy) in ((1.7, 3.6, 0, 0), (1.2, 4.7, 0.3, 0.2), (1.0, 3.3, -0.9, 0.4)):
            c = self._textured(geo.sphere(r, 10, 7).scaled(1, 1, 0.85), "crown", self.tex["leaves"],
                               (0.9, 1.0, 0.85), hi)
            c.setPos(ox, oy, z)
        hi.flattenStrong()
        lo = self.root.attachNewNode("tree_lo_proto")
        t2 = self._textured(geo.cylinder(0.2, 0.14, 2.8, 5), "trunk_lo", self.tex["bark"], parent=lo)
        c2 = self._textured(geo.cylinder(2.0, 0.0, 4.5, 6), "crown_lo", self.tex["leaves"], (0.9, 1.0, 0.85), lo)
        c2.setZ(2.2)
        lo.flattenStrong()
        for n in (hi, lo):
            n.detachNode()
        for x, y, s in self.layout.trees:
            tn = self.root.attachNewNode("tree")
            tn.setPos(x, y, 0)
            tn.setScale(s)
            tn.setH(self.rng.uniform(0, 360))
            h = tn.attachNewNode("hi")
            hi.instanceTo(h)
            l = tn.attachNewNode("lo")
            lo.instanceTo(l)
            l.hide()
            self._static_cylinder("tree", x, y, 0.3 * s, 3.0 * s)
            self.cull_items.append((tn, x, y, 4.0, "tree", (h, l)))

    def _build_lamps(self):
        pole = self.root.attachNewNode("lamps")
        for x, y in self.layout.lamps:
            p = self._textured(geo.cylinder(0.08, 0.06, 6.0, 6), "pole", None, (0.15, 0.15, 0.17), pole)
            p.setPos(x, y, 0)
            head = self._textured(geo.box(0.5, 0.5, 0.2), "head", None, (1.0, 0.92, 0.65), pole)
            head.setPos(x, y, 6.1)
            head.setLightOff()
        pole.flattenStrong()
        self.lamp_np = pole
        self.cull_items.append((pole, 0, 0, 1e9, "always"))

    def _make_car(self, color):
        car = self.root.attachNewNode("car")
        body = self._textured(geo.box(1.9, 4.4, 0.7).translated(0, 0, 0.7), "body", None, color, car)
        set_material(body, color, 0.25, 0.7)
        cab = self._textured(geo.box(1.65, 2.2, 0.6).translated(0, -0.2, 1.3), "cabin", None, (0.1, 0.14, 0.2), car)
        set_material(cab, (0.1, 0.14, 0.2), 0.1, 0.3)
        for sx in (-0.95, 0.95):
            for sy in (-1.4, 1.4):
                w = self._textured(geo.cylinder(0.36, 0.36, 0.26, 10), "wheel", None, (0.04, 0.04, 0.04), car)
                w.setPos(sx, sy, 0.36)
                w.setR(90)
        car.flattenStrong()
        return car

    def _build_cars(self):
        L = self.layout
        for c in L.parked:
            car = self._make_car(CAR_COLORS[c.color_idx])
            car.setPos(c.x, c.y, 0)
            car.setH(c.heading)
            self.cull_items.append((car, c.x, c.y, 4.0, "prop"))
        for _ in range(self.q["traffic"]):
            line = self.rng.choice(L.road_lines)
            axis = self.rng.choice("xy")
            d = self.rng.choice((-1, 1))
            car = self._make_car(CAR_COLORS[self.rng.randrange(6)])
            self.traffic.append(dict(np=car, line=line, axis=axis, dir=d, s=self.rng.uniform(-L.half_extent, L.half_extent),
                                     speed=self.rng.uniform(7, 12)))

    def _build_beacon(self):
        b = self.root.attachNewNode("beacon")
        beam = self._textured(geo.cylinder(1.3, 1.3, 70, 16, caps=False), "beam", None, (0.2, 0.85, 1.0), b)
        beam.setTransparency(TransparencyAttrib.MAlpha)
        beam.setColor(0.2, 0.85, 1.0, 0.28)
        beam.setLightOff()
        beam.setTwoSided(True)
        beam.setDepthWrite(False)
        beam.setBin("transparent", 10)
        ring = self._textured(geo.cylinder(2.2, 2.2, 0.15, 24), "ring", None, (0.2, 0.85, 1.0), b)
        ring.setLightOff()
        b.setPos(self.layout.beacon[0], self.layout.beacon[1], 0)
        self.beacon_np = b

    def _build_boundary(self):
        e = self.layout.half_extent + 110
        for sx, sy, hx, hy in ((e, 0, 1, e), (-e, 0, 1, e), (0, e, e, 1), (0, -e, e, 1)):
            self._static_box("wall", (sx, sy, 10), (hx, hy, 10))

    # ---------------------------------------------------------------- sky & light
    def _build_sky(self):
        self.sky = mesh_to_nodepath(geo.sphere(1000, 24, 16), "sky")
        self.sky.reparentTo(self.base.render)
        sh = Shader.load(Shader.SL_GLSL, vertex=str(C.SHADERS / "sky.vert"), fragment=str(C.SHADERS / "sky.frag"))
        self.sky.setShader(sh, 100)
        self.sky.setTwoSided(True)
        self.sky.setBin("background", 0)
        self.sky.setDepthWrite(False)
        self.sky.setDepthTest(False)
        self.sky.setLightOff()
        self.sky.setFogOff()

        # stars
        fmt = GeomVertexFormat.getV3()
        vd = GeomVertexData("stars", fmt, Geom.UHStatic)
        w = GeomVertexWriter(vd, "vertex")
        n = 500
        for _ in range(n):
            z = self.rng.uniform(0.05, 1.0)
            a = self.rng.uniform(0, math.tau)
            r = math.sqrt(1 - z * z)
            w.addData3(900 * r * math.cos(a), 900 * r * math.sin(a), 900 * z)
        prim = GeomPoints(Geom.UHStatic)
        prim.addConsecutiveVertices(0, n)
        prim.closePrimitive()
        g = Geom(vd)
        g.addPrimitive(prim)
        gn = GeomNode("stars")
        gn.addGeom(g)
        self.stars = self.base.render.attachNewNode(gn)
        self.stars.setRenderModeThickness(2)
        self.stars.setLightOff()
        self.stars.setFogOff()
        self.stars.setTransparency(TransparencyAttrib.MAlpha)
        self.stars.setBin("background", 1)
        self.stars.setDepthWrite(False)

        # clouds
        self.clouds = []
        for _ in range(16):
            c = mesh_to_nodepath(geo.sphere(1.0, 10, 6), "cloud")
            c.reparentTo(self.base.render)
            sx = self.rng.uniform(40, 90)
            c.setScale(sx, sx * self.rng.uniform(0.5, 0.9), sx * 0.22)
            cx = self.rng.uniform(-700, 700)
            c.setPos(cx, self.rng.uniform(-700, 700), self.rng.uniform(150, 260))
            c.setLightOff()
            c.setFogOff()
            c.setTransparency(TransparencyAttrib.MAlpha)
            c.setDepthWrite(False)
            c.setBin("background", 2)
            self.clouds.append([c, self.rng.uniform(1.5, 4.0), self.rng.random(), cx])

    def _build_lights(self):
        r = self.base.render
        self.ambient = AmbientLight("ambient")
        self.ambient_np = r.attachNewNode(self.ambient)
        r.setLight(self.ambient_np)
        self.sun = DirectionalLight("sun")
        self.sun_np = r.attachNewNode(self.sun)
        r.setLight(self.sun_np)
        lens = self.sun.getLens()
        lens.setFilmSize(110, 110)
        lens.setNearFar(10, 300)
        self.fog = Fog("fog")
        r.setFog(self.fog)
        self.apply_quality(None)

    def apply_quality(self, name):
        if name:
            self.q = C.QUALITY_PRESETS[name]
        s = self.q["shadow_size"]
        self.sun.setShadowCaster(False)
        self.sun.setShadowCaster(True, s, s)

    def _build_rain(self):
        n = self.q["particles"]
        ls = LineSegs()
        ls.setThickness(1.2)
        H = 30.0
        self.rain_h = H
        for _ in range(n):
            x, y, z = self.rng.uniform(-18, 18), self.rng.uniform(-18, 18), self.rng.uniform(0, H)
            ls.moveTo(x, y, z)
            ls.drawTo(x + 0.15, y, z - 0.8)
        proto = self.base.render.attachNewNode(ls.create())
        proto.detachNode()
        self.rain = self.base.render.attachNewNode("rain")
        self.rain.setLightOff()
        self.rain.setFogOff()
        self.rain.setTransparency(TransparencyAttrib.MAlpha)
        self.rain.setDepthWrite(False)
        self.rain_a = self.rain.attachNewNode("a")
        self.rain_b = self.rain.attachNewNode("b")
        proto.instanceTo(self.rain_a)
        proto.instanceTo(self.rain_b)
        self.rain.hide()

    # ---------------------------------------------------------------- per frame
    def set_hour(self, h):
        self.hour = h % 24.0

    def update(self, dt, focus, cam_pos=None):
        self.hour = (self.hour + dt * 24.0 / C.DAY_LENGTH_SECONDS * self.time_scale) % 24.0
        rain, fog, cloud = self.weather.update(dt)
        d = daycycle.sample(self.hour)
        dim = 1.0 - 0.45 * cloud - 0.25 * rain
        sun_dir = Vec3(*daycycle.sun_direction(self.hour))
        sun_dir.normalize()
        k = d["strength"] * dim
        self.sun.setColor(Vec4(d["sun"][0] * k, d["sun"][1] * k, d["sun"][2] * k, 1))
        a = d["ambient"]
        self.ambient.setColor(Vec4(a[0] * (1 + 0.3 * cloud), a[1] * (1 + 0.3 * cloud), a[2] * (1 + 0.3 * cloud), 1))
        self.sun_np.setPos(focus + sun_dir * 150)
        self.sun_np.lookAt(focus)

        grey = sum(d["sky"]) / 3.0
        mix = min(1.0, 0.7 * cloud + 0.5 * rain + 0.3 * fog)
        zen = tuple(c * (1 - mix) + grey * 0.8 * mix for c in d["sky"])
        hor = tuple(min(1.0, (c * 1.25 + 0.1 * (1 - mix)) * (1 - mix) + grey * 1.2 * mix) for c in d["sky"])
        if fog > 0.2:
            f = fog
            hor = tuple(c * (1 - f) + grey * 1.4 * f for c in hor)
            zen = tuple(c * (1 - 0.6 * f) + grey * 1.3 * 0.6 * f for c in zen)
        self.sky.setShaderInput("zenith", Vec3(*zen))
        self.sky.setShaderInput("horizon", Vec3(*hor))
        self.sky.setShaderInput("sunDir", sun_dir)
        self.sky.setShaderInput("sunColor", Vec3(*d["sun"]))
        self.sky.setShaderInput("sunVisible", float(1.0 - 0.85 * max(cloud, fog)))
        self.base.setBackgroundColor(hor[0], hor[1], hor[2], 1)
        self.fog.setColor(hor[0], hor[1], hor[2])
        self.fog.setExpDensity(0.0016 + 0.018 * fog + 0.004 * rain)

        cam = cam_pos if cam_pos is not None else focus
        self.sky.setPos(cam)
        self.stars.setPos(cam)
        self.stars.setColor(1, 1, 1, daycycle.star_alpha(self.hour) * (1 - mix))
        bright = max(0.25, min(1.0, grey * 2.2 + 0.2))
        for item in self.clouds:
            c, speed, ph, x = item
            x += speed * dt
            if x > 800:
                x = -800
            item[3] = x
            c.setX(x)
            c.setColor(bright * 0.95, bright * 0.97, bright, max(0.0, min(0.85, cloud * 1.2 - ph * 0.3)))

        # rain
        if rain > 0.05:
            self.rain.show()
            self._rain_t += dt
            off = -((self._rain_t * 22.0) % self.rain_h)
            base_z = cam.z - self.rain_h / 2 + off
            self.rain.setPos(cam.x, cam.y, 0)
            self.rain_a.setZ(base_z)
            self.rain_b.setZ(base_z + self.rain_h)
            self.rain.setColor(0.75, 0.8, 0.95, min(0.55, rain * 0.6))
        else:
            self.rain.hide()

        # beacon pulse
        s = 1.0 + 0.08 * math.sin(self.hour * 600.0 + self._rain_t * 3.0)
        self.beacon_np.setScale(s, s, 1.0)

        # traffic
        he = self.layout.half_extent
        for t in self.traffic:
            t["s"] += t["dir"] * t["speed"] * dt
            if t["s"] > he + 10:
                t["s"] = -he - 10
            elif t["s"] < -he - 10:
                t["s"] = he + 10
            lane = self.layout.lane_center(t["line"], t["dir"] if t["axis"] == "y" else -t["dir"])
            t["x"], t["y"] = (lane, t["s"]) if t["axis"] == "y" else (t["s"], lane)
            if t["axis"] == "y":
                t["np"].setPos(lane, t["s"], 0)
                t["np"].setH(0 if t["dir"] > 0 else 180)
            else:
                t["np"].setPos(t["s"], lane, 0)
                t["np"].setH(-90 if t["dir"] > 0 else 90)

        self._cull_timer -= dt
        if self._cull_timer <= 0:
            self._cull_timer = 0.25
            self._cull(cam)

    def _cull(self, cam):
        draw = self.q["draw_distance"]
        lod = self.q["tree_lod_distance"]
        for item in self.cull_items:
            np, x, y, r, kind = item[:5]
            if kind == "always":
                continue
            d2 = (x - cam.x) ** 2 + (y - cam.y) ** 2
            far = draw + r
            if d2 > far * far:
                if not np.isHidden():
                    np.hide()
                continue
            if np.isHidden():
                np.show()
            if kind == "tree":
                h, l = item[5]
                near = d2 < lod * lod
                if near and h.isHidden():
                    h.show()
                    l.hide()
                elif not near and not h.isHidden():
                    h.hide()
                    l.show()

    # ---------------------------------------------------------------- queries
    def traffic_hit(self, x, y, radius=0.4):
        for t in self.traffic:
            if "x" not in t:
                continue
            hw, hl = (1.0, 2.3) if t["axis"] == "y" else (2.3, 1.0)
            if abs(t["x"] - x) < hw + radius and abs(t["y"] - y) < hl + radius:
                return True
        return False

    def is_night(self):
        return daycycle.is_night(self.hour)
