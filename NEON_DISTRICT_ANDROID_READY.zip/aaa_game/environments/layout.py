"""Procedural city layout. Pure Python: used by the renderer AND by physics/AI/tests."""
import math
import random
from dataclasses import dataclass


@dataclass(frozen=True)
class Rect:
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def cx(self):
        return (self.x0 + self.x1) / 2

    @property
    def cy(self):
        return (self.y0 + self.y1) / 2

    @property
    def w(self):
        return self.x1 - self.x0

    @property
    def d(self):
        return self.y1 - self.y0

    def contains(self, x, y, margin=0.0):
        return self.x0 - margin <= x <= self.x1 + margin and self.y0 - margin <= y <= self.y1 + margin


@dataclass(frozen=True)
class Building:
    rect: Rect
    height: float
    style: int  # index into facade textures


@dataclass(frozen=True)
class Car:
    x: float
    y: float
    heading: float  # degrees, 0 = +Y
    color_idx: int


class CityLayout:
    def __init__(self, seed=7, blocks=5, block_size=44.0, road_width=14.0):
        assert blocks % 2 == 1, "blocks must be odd so a park sits in the middle"
        self.rng = random.Random(seed)
        self.blocks, self.bs, self.rw = blocks, block_size, road_width
        self.pitch = block_size + road_width
        self.half_extent = blocks * self.pitch / 2.0
        self.road_lines = [(k - blocks / 2.0) * self.pitch for k in range(blocks + 1)]
        self.block_rects = []
        self.buildings = []
        self.trees = []        # (x, y, scale)
        self.lamps = []        # (x, y)
        self.parked = []       # Car
        self.park_rect = None
        self.beacon = (0.0, 0.0)
        self._build()

    # ------------------------------------------------------------------
    def _build(self):
        n, bs = self.blocks, self.bs
        mid = n // 2
        for i in range(n):
            for j in range(n):
                cx = (i - (n - 1) / 2.0) * self.pitch
                cy = (j - (n - 1) / 2.0) * self.pitch
                rect = Rect(cx - bs / 2, cy - bs / 2, cx + bs / 2, cy + bs / 2)
                self.block_rects.append(rect)
                if i == mid and j == mid:
                    self.park_rect = rect
                    self._fill_park(rect)
                else:
                    self._fill_block(rect, downtown=abs(i - mid) + abs(j - mid) <= 2)
                self._street_trees_and_lamps(rect)
        self._parked_cars()

    def _fill_block(self, rect, downtown):
        lot = self.bs / 2.0
        for a in range(2):
            for b in range(2):
                lx0, ly0 = rect.x0 + a * lot, rect.y0 + b * lot
                w = self.rng.uniform(13, lot - 5)
                d = self.rng.uniform(13, lot - 5)
                ox = self.rng.uniform(3.0, lot - w - 2.0)
                oy = self.rng.uniform(3.0, lot - d - 2.0)
                height = self.rng.uniform(22, 60) if downtown else self.rng.uniform(9, 26)
                r = Rect(lx0 + ox, ly0 + oy, lx0 + ox + w, ly0 + oy + d)
                self.buildings.append(Building(r, height, self.rng.randrange(3)))

    def _fill_park(self, rect):
        for _ in range(34):
            x = self.rng.uniform(rect.x0 + 3, rect.x1 - 3)
            y = self.rng.uniform(rect.y0 + 3, rect.y1 - 3)
            if math.hypot(x, y) > 6.0:
                self.trees.append((x, y, self.rng.uniform(0.8, 1.5)))

    def _street_trees_and_lamps(self, rect):
        step = 11.0
        t = step / 2
        while t < self.bs:
            for (x, y) in ((rect.x0 + t, rect.y0 + 1.4), (rect.x0 + t, rect.y1 - 1.4),
                           (rect.x0 + 1.4, rect.y0 + t), (rect.x1 - 1.4, rect.y0 + t)):
                if rect is not self.park_rect or self.rng.random() < 0.5:
                    self.trees.append((x, y, self.rng.uniform(0.8, 1.2)))
            t += step
        for (x, y) in ((rect.x0 + 1.0, rect.y0 + 1.0), (rect.x1 - 1.0, rect.y0 + 1.0),
                       (rect.x0 + 1.0, rect.y1 - 1.0), (rect.x1 - 1.0, rect.y1 - 1.0)):
            self.lamps.append((x, y))

    def _parked_cars(self):
        off = 5.4
        for line in self.road_lines:
            for k in range(self.blocks):
                for side in (-1, 1):
                    if self.rng.random() < 0.55:
                        along = (k - (self.blocks - 1) / 2.0) * self.pitch + self.rng.uniform(-14, 14)
                        # road running along Y at x=line
                        self.parked.append(Car(line + side * off, along, 0.0, self.rng.randrange(6)))
                    if self.rng.random() < 0.55:
                        along = (k - (self.blocks - 1) / 2.0) * self.pitch + self.rng.uniform(-14, 14)
                        self.parked.append(Car(along, line + side * off, 90.0, self.rng.randrange(6)))
        # remove cars that overlap intersections (|offset| of both axes near a road centre)
        keep = []
        for c in self.parked:
            near_x = min(abs(c.x - l) for l in self.road_lines)
            near_y = min(abs(c.y - l) for l in self.road_lines)
            if not (near_x < self.rw / 2 + 3 and near_y < self.rw / 2 + 3):
                keep.append(c)
        self.parked = keep

    # ------------------------------------------------------------------
    CAR_HALF = (1.0, 2.3)  # half width, half length of a car footprint (heading 0)

    def car_rect(self, car, pad=0.0):
        hw, hl = self.CAR_HALF
        if abs(car.heading % 180.0) > 45:
            hw, hl = hl, hw
        return Rect(car.x - hw - pad, car.y - hl - pad, car.x + hw + pad, car.y + hl + pad)

    @property
    def colliders(self):
        """Axis-aligned rectangles that block walking: buildings and parked cars."""
        return [b.rect for b in self.buildings] + [self.car_rect(c) for c in self.parked]

    @property
    def tree_colliders(self):
        return [(x, y, 0.35 * s) for x, y, s in self.trees]

    def is_free(self, x, y, radius=0.5):
        half = self.half_extent
        if abs(x) > half or abs(y) > half:
            return False
        for r in self.colliders:
            if r.contains(x, y, radius):
                return False
        for tx, ty, tr in self.tree_colliders:
            if (tx - x) ** 2 + (ty - y) ** 2 < (tr + radius) ** 2:
                return False
        return True

    def random_free_point(self, rng, radius=0.8, min_dist_from=None, min_dist=0.0, tries=500):
        for _ in range(tries):
            x = rng.uniform(-self.half_extent, self.half_extent)
            y = rng.uniform(-self.half_extent, self.half_extent)
            if not self.is_free(x, y, radius):
                continue
            if min_dist_from and math.hypot(x - min_dist_from[0], y - min_dist_from[1]) < min_dist:
                continue
            return (x, y)
        raise RuntimeError("no free point found")

    @property
    def spawn_point(self):
        # on the sidewalk just south of the park
        r = self.park_rect
        return (0.0, r.y0 - 3.0)

    def lane_center(self, line, direction):
        """x/y offset of a traffic lane for a road at `line` (direction +1/-1)."""
        return line + 2.6 * direction
