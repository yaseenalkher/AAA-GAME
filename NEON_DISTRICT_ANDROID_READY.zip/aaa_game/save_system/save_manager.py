"""JSON save/load with atomic writes, versioning and corruption tolerance."""
import json
import os
import tempfile
import time
from pathlib import Path

from config import DEFAULT_SETTINGS, SAVE_DIR

SAVE_VERSION = 1


class SaveManager:
    SLOTS = 3

    def __init__(self, directory=None):
        self.dir = Path(directory) if directory else SAVE_DIR
        self.dir.mkdir(parents=True, exist_ok=True)

    # ---- helpers -------------------------------------------------
    def _atomic_write(self, path, data):
        fd, tmp = tempfile.mkstemp(dir=self.dir, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    def _read(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    # ---- game slots ----------------------------------------------
    def slot_path(self, slot):
        assert 0 <= slot < self.SLOTS
        return self.dir / f"slot{slot}.json"

    def save_game(self, slot, state):
        data = dict(version=SAVE_VERSION, saved_at=time.time(), state=state)
        self._atomic_write(self.slot_path(slot), data)

    def load_game(self, slot):
        data = self._read(self.slot_path(slot))
        if not isinstance(data, dict) or data.get("version") != SAVE_VERSION:
            return None
        return data.get("state")

    def has_save(self, slot=0):
        return self.load_game(slot) is not None

    def latest_slot(self):
        best, best_t = None, -1
        for s in range(self.SLOTS):
            d = self._read(self.slot_path(s))
            if isinstance(d, dict) and d.get("version") == SAVE_VERSION and d.get("saved_at", 0) > best_t:
                best, best_t = s, d["saved_at"]
        return best

    def delete_game(self, slot):
        try:
            self.slot_path(slot).unlink()
        except FileNotFoundError:
            pass

    # ---- settings ------------------------------------------------
    def load_settings(self):
        merged = dict(DEFAULT_SETTINGS)
        data = self._read(self.dir / "settings.json")
        if isinstance(data, dict):
            for k, v in data.items():
                if k in merged and isinstance(v, type(merged[k])):
                    merged[k] = v
        return merged

    def save_settings(self, settings):
        self._atomic_write(self.dir / "settings.json", settings)
