"""Player: Bullet character controller, 3rd/1st person camera, stamina, melee attack."""
import math

from panda3d.bullet import BulletCapsuleShape, BulletCharacterControllerNode, ZUp
from panda3d.core import BitMask32, Point3, Vec3

import config as C
from ai.npc_ai import angle_to
from animations import procedural as anim
from characters.humanoid import Humanoid

P = C.PLAYER


class Player:
    def __init__(self, game, appearance, spawn_xy, heading=0.0):
        self.game = game
        self.bw = game.bullet
        h = P["height"]
        shape = BulletCapsuleShape(P["radius"], h - 2 * P["radius"], ZUp)
        self.cc = BulletCharacterControllerNode(shape, 0.4, "player")
        self.cc.setMaxJumpHeight(P["jump_height"])
        self.cc.setJumpSpeed(6.5)
        self.cc.setGravity(20.0)
        self.np = game.render.attachNewNode(self.cc)
        self.np.setPos(spawn_xy[0], spawn_xy[1], h / 2 + 0.1)
        self.np.setCollideMask(BitMask32.bit(0) | BitMask32.bit(1))
        self.bw.attachCharacter(self.cc)

        self.body = Humanoid(self.np, appearance, "player_body")
        self.body.root.setZ(-h / 2)
        self.eye_height = 0.91 * appearance["height"]

        self.health = P["max_health"]
        self.stamina = P["max_stamina"]
        self.alive = True
        self.heading = heading
        self.cam_h = heading
        self.cam_p = -12.0
        self.cam_dist = 4.2
        self.first_person = False
        self.phase = 0.0
        self.t = 0.0
        self.state = "idle"
        self.state_t = 0.0
        self.attack_cd = 0.0
        self.attack_hit_done = True
        self.invuln = 0.0
        self.last_z = self.np.getZ()
        self.vz = 0.0
        self.speed = 0.0
        self.sprinting = False
        self._last_step_sign = 1
        self.on_ground = True
        self.death_t = 0.0

    # ---------------------------------------------------------------- state
    @property
    def xy(self):
        p = self.np.getPos()
        return (p.x, p.y)

    def teleport(self, x, y):
        self.np.setPos(x, y, P["height"] / 2 + 0.1)

    def toggle_camera(self):
        self.first_person = not self.first_person
        self.body.root.show() if not self.first_person else self.body.root.hide()

    def take_damage(self, amount):
        if not self.alive or self.invuln > 0:
            return False
        self.health = max(0.0, self.health - amount)
        self.invuln = 0.6
        self.state = "hit"
        self.state_t = 0.0
        self.game.audio.play("hit", 0.9)
        self.game.ui.flash_damage()
        if self.health <= 0:
            self.alive = False
            self.state = "dead"
            self.state_t = 0.0
            self.death_t = 0.0
            self.body.set_expression("hurt")
            return True
        return False

    def heal(self, amount):
        self.health = min(P["max_health"], self.health + amount)

    def revive(self, xy):
        self.health = P["max_health"]
        self.stamina = P["max_stamina"]
        self.alive = True
        self.state = "idle"
        self.invuln = 2.0
        self.teleport(*xy)
        self.body.set_expression("calm")

    # ---------------------------------------------------------------- update
    def update(self, dt, keys, mouse_delta, npcs, settings):
        self.t += dt
        self.state_t += dt
        self.invuln = max(0.0, self.invuln - dt)
        self.attack_cd = max(0.0, self.attack_cd - dt)

        # --- camera look
        sens = settings["mouse_sensitivity"]
        dx, dy = mouse_delta
        self.cam_h -= dx * sens
        inv = -1 if settings["invert_y"] else 1
        self.cam_p = max(-75.0, min(60.0 if not self.first_person else 80.0, self.cam_p - dy * sens * inv))

        pos = self.np.getPos()
        self.vz = (pos.z - self.last_z) / dt if dt > 0 else 0.0
        self.last_z = pos.z
        self.on_ground = self.cc.isOnGround()

        if not self.alive:
            self.cc.setLinearMovement(Vec3(0, 0, 0), False)
            self.death_t += dt
            self.body.apply_pose(anim.dead_pose(self.state_t))
            self._update_camera(dt)
            return

        # --- movement
        fx = (1 if keys["forward"] else 0) - (1 if keys["back"] else 0)
        sx = (1 if keys["right"] else 0) - (1 if keys["left"] else 0)
        attacking = self.state == "attack"
        moving = (fx or sx) and not attacking
        want_sprint = keys["sprint"] and moving and fx >= 0 and self.stamina > 4
        if want_sprint:
            self.stamina = max(0.0, self.stamina - P["stamina_drain"] * dt)
        else:
            self.stamina = min(P["max_stamina"], self.stamina + P["stamina_regen"] * dt)
        self.sprinting = bool(want_sprint)
        spd = P["run_speed"] if want_sprint else P["walk_speed"]

        hr = math.radians(self.cam_h)
        fwd = Vec3(-math.sin(hr), math.cos(hr), 0)
        right = Vec3(math.cos(hr), math.sin(hr), 0)
        vel = Vec3(0, 0, 0)
        if moving:
            vel = fwd * fx + right * sx
            vel.normalize()
            vel *= spd
        if not self.on_ground:
            vel *= 0.85
        self.cc.setLinearMovement(vel, False)
        self.speed = vel.length()

        # --- facing
        if self.first_person:
            self.heading = self.cam_h
        elif self.speed > 0.1:
            want = angle_to(vel.x, vel.y)
            diff = (want - self.heading + 180) % 360 - 180
            self.heading += max(-self.turn_rate(dt), min(self.turn_rate(dt), diff))
        elif attacking:
            diff = (self.cam_h - self.heading + 180) % 360 - 180
            self.heading += max(-600 * dt, min(600 * dt, diff))
        self.body.root.setH(self.heading - self.np.getH())  # node itself is not rotated

        # --- jump / attack
        if keys.pop("jump_pressed", False) and self.cc.canJump() and not attacking:
            self.cc.doJump()
            self.game.audio.play("jump", 0.6)
        if keys.pop("attack_pressed", False) and self.attack_cd <= 0 and self.on_ground:
            self.state = "attack"
            self.state_t = 0.0
            self.attack_cd = P["attack_cooldown"]
            self.attack_hit_done = False
            self.game.audio.play("swing", 0.8)

        # --- state machine
        if self.state == "attack":
            t = self.state_t / 0.45
            if not self.attack_hit_done and t >= 0.45:
                self.attack_hit_done = True
                self._do_attack_hit(npcs)
            if t >= 1.0:
                self.state = "idle"
        elif self.state == "hit":
            if self.state_t > 0.35:
                self.state = "idle"
        if self.state in ("idle", "move", "air"):
            self.state = "air" if not self.on_ground else ("move" if self.speed > 0.1 else "idle")

        run = 1.0 if self.sprinting else 0.0
        self.phase += anim.stride_frequency(self.speed) * 2 * math.pi * dt
        st = self.state_t
        if self.state == "attack":
            st = self.state_t / 0.45
        pose = anim.pose_for(self.state, self.t, speed=self.speed, phase=self.phase,
                             vz=self.vz, state_t=st, run_amount=run)
        self.body.apply_pose(pose)

        # footsteps on each half stride
        if self.state == "move" and self.on_ground:
            sign = 1 if math.sin(self.phase) >= 0 else -1
            if sign != self._last_step_sign:
                self.game.audio.footstep(self.sprinting)
            self._last_step_sign = sign
        self._update_camera(dt)

    def turn_rate(self, dt):
        return 720.0 * dt

    def _do_attack_hit(self, npcs):
        px, py = self.xy
        hr = math.radians(self.heading)
        fx, fy = -math.sin(hr), math.cos(hr)
        for npc in npcs:
            b = npc.brain
            if not b.alive or b.kind == "guide":
                continue
            dx, dy = b.x - px, b.y - py
            d = math.hypot(dx, dy)
            if d > P["attack_range"] + b.radius:
                continue
            if d > 0.05 and (dx * fx + dy * fy) / d < math.cos(math.radians(70)):
                continue
            killed = b.take_hit(P["attack_damage"], (px, py))
            self.game.audio.play("hit", 0.8)
            if killed:
                self.game.on_enemy_defeated(npc)

    # ---------------------------------------------------------------- camera
    def _update_camera(self, dt):
        cam = self.game.camera
        pos = self.np.getPos()
        hr, pr = math.radians(self.cam_h), math.radians(self.cam_p)
        look = Vec3(-math.sin(hr) * math.cos(pr), math.cos(hr) * math.cos(pr), math.sin(pr))
        feet_z = pos.z - P["height"] / 2
        if self.first_person:
            cam.setPos(pos.x, pos.y, feet_z + self.eye_height)
            cam.setHpr(self.cam_h, self.cam_p, 0)
            return
        pivot = Point3(pos.x, pos.y, feet_z + self.eye_height - 0.1)
        desired = pivot - look * self.cam_dist + Vec3(0, 0, 0.3)
        res = self.bw.rayTestClosest(pivot, desired, BitMask32.bit(0))
        if res.hasHit():
            frac = max(0.12, res.getHitFraction() - 0.06)
            desired = pivot + (desired - pivot) * frac
        cam.setPos(desired)
        cam.lookAt(pivot + Vec3(0, 0, 0.1))

    def destroy(self):
        self.bw.removeCharacter(self.cc)
        self.np.removeNode()
