"""All menus and the HUD, built with Panda3D DirectGUI (modern flat dark style)."""
from direct.gui import DirectGuiGlobals as DGG
from direct.gui.DirectGui import (DirectButton, DirectFrame, DirectLabel, DirectSlider,
                                  DirectWaitBar)
from direct.gui.OnscreenText import OnscreenText
from direct.interval.IntervalGlobal import Func, LerpColorScaleInterval, Sequence
from panda3d.core import TextNode, TransparencyAttrib

import config as C

BG = (0.03, 0.04, 0.08, 0.86)
ACCENT = (0.0, 0.78, 1.0, 1)
TEXT = (0.92, 0.95, 1.0, 1)
BTN = ((0.10, 0.13, 0.22, 0.95), (0.0, 0.55, 0.75, 1), (0.14, 0.30, 0.48, 1), (0.1, 0.1, 0.1, 0.5))


class UI:
    def __init__(self, game):
        self.game = game
        a2d = game.aspect2d
        self.screens = {}
        self.msg_queue = []
        self.msg_timer = 0.0
        self._build_hud(a2d)
        self._build_title(a2d)
        self._build_main_menu(a2d)
        self._build_character(a2d)
        self._build_settings(a2d)
        self._build_pause(a2d)
        self._build_end(a2d, "win", "MISSION COMPLETE", (0.2, 1.0, 0.5, 1))
        self._build_end(a2d, "lose", "YOU WERE DEFEATED", (1.0, 0.3, 0.3, 1))
        self.damage = DirectFrame(parent=game.render2d, frameColor=(0.8, 0.0, 0.0, 0.0),
                                  frameSize=(-1, 1, -1, 1))
        self.damage.setTransparency(TransparencyAttrib.MAlpha)
        self.fade_frame = DirectFrame(parent=game.render2d, frameColor=(0, 0, 0, 1), frameSize=(-1, 1, -1, 1))
        self.fade_frame.setTransparency(TransparencyAttrib.MAlpha)
        self.fade_frame.setColorScale(1, 1, 1, 0)
        self.fade_frame.hide()
        self.hide_all()

    # ---------------------------------------------------------------- helpers
    def _panel(self, name, parent, size=(-0.8, 0.8, -0.85, 0.85), color=BG):
        f = DirectFrame(parent=parent, frameColor=color, frameSize=size)
        f.hide()
        self.screens[name] = f
        return f

    def _button(self, parent, text, pos, cmd, scale=0.07, width=9.0, args=()):
        def click(*a):
            self.game.audio.play("click", 0.6)
            cmd(*args)
        return DirectButton(parent=parent, text=text, text_scale=1, scale=scale, pos=(pos[0], 0, pos[1]),
                            frameSize=(-width / 2, width / 2, -0.7, 1.0), frameColor=BTN, text_fg=TEXT,
                            relief=DGG.FLAT, command=click, pressEffect=1, text_pos=(0, -0.2))

    def _label(self, parent, text, pos, scale=0.06, color=TEXT, align=TextNode.ACenter):
        return DirectLabel(parent=parent, text=text, pos=(pos[0], 0, pos[1]), scale=scale, text_fg=color,
                           frameColor=(0, 0, 0, 0), text_align=align)

    def hide_all(self):
        for s in self.screens.values():
            s.hide()
        self.hud.hide()

    def show(self, name):
        self.hide_all()
        if name == "hud":
            self.hud.show()
        else:
            self.screens[name].show()

    # ---------------------------------------------------------------- title / menu
    def _build_title(self, a2d):
        f = self._panel("title", a2d, (-2, 2, -1, 1), (0, 0, 0, 0.35))
        self._label(f, C.GAME_TITLE, (0, 0.35), 0.2, ACCENT)
        self._label(f, "An open-world 3D action game in Python", (0, 0.2), 0.055, (0.8, 0.85, 0.95, 1))
        self._button(f, "PRESS TO START", (0, -0.2), self.game.go_main_menu, 0.08, 9)
        self._label(f, "Panda3D  |  Bullet physics  |  Procedural assets", (0, -0.9), 0.04, (0.6, 0.65, 0.75, 1))

    def _build_main_menu(self, a2d):
        f = self._panel("menu", a2d, (-2, 2, -1, 1), (0, 0, 0, 0.15))
        card = DirectFrame(parent=f, frameColor=BG, frameSize=(-0.55, 0.55, -0.7, 0.75), pos=(-0.9, 0, 0))
        self._label(card, C.GAME_TITLE, (0, 0.6), 0.1, ACCENT)
        self.btn_continue = self._button(card, "CONTINUE", (0, 0.38), self.game.continue_game, 0.065, 8)
        self._button(card, "NEW GAME", (0, 0.2), self.game.new_game_character, 0.065, 8)
        self._button(card, "SETTINGS", (0, 0.02), lambda: self.game.go_settings("menu"), 0.065, 8)
        self._button(card, "QUIT", (0, -0.16), self.game.quit, 0.065, 8)
        self._label(card, "WASD move | Shift sprint | Space jump\nMouse look | LMB attack | E interact\n"
                          "V camera | Esc pause | F5 save | F6 weather | F7 +3h",
                    (0, -0.42), 0.04, (0.7, 0.75, 0.85, 1))
        self.btn_continue_label = None

    def refresh_menu(self):
        self.btn_continue["state"] = DGG.NORMAL if self.game.saves.latest_slot() is not None else DGG.DISABLED

    # ---------------------------------------------------------------- character select
    def _cycler(self, parent, label, y, options, key):
        game = self.game
        self._label(parent, label, (-0.42, y), 0.05, (0.7, 0.8, 0.95, 1), TextNode.ALeft)
        val = DirectLabel(parent=parent, text="", pos=(0.12, 0, y), scale=0.05, text_fg=ACCENT,
                          frameColor=(0, 0, 0, 0))

        def refresh():
            cur = game.appearance[key]
            val["text"] = str(cur if not isinstance(cur, float) else f"{cur:.2f} m")

        def step(d):
            cur = game.appearance[key]
            if isinstance(options[0], str):
                i = (options.index(cur) + d) % len(options)
                game.appearance[key] = options[i]
            elif isinstance(options[0], float):
                game.appearance[key] = round(max(options[0], min(options[-1], cur + d * 0.03)), 2)
            else:
                game.appearance[key] = (cur + d) % len(options)
            refresh()
            game.refresh_preview()
        self._button(parent, "<", (-0.05, y + 0.012), step, 0.05, 1.2, (-1,))
        self._button(parent, ">", (0.3, y + 0.012), step, 0.05, 1.2, (1,))
        refresh()
        return refresh

    def _build_character(self, a2d):
        f = self._panel("character", a2d, (-2, 2, -1, 1), (0, 0, 0, 0))
        card = DirectFrame(parent=f, frameColor=BG, frameSize=(-0.5, 0.5, -0.85, 0.8), pos=(0.95, 0, 0))
        self._label(card, "CHOOSE YOUR CHARACTER", (0, 0.68), 0.06, ACCENT)
        y = 0.52
        self._refreshers = []
        for label, key, opts in (("Body", "body", list(C.BODY_TYPES)),
                                 ("Height", "height", [1.55, 2.0]),
                                 ("Skin", "skin", list(range(len(C.SKIN_TONES)))),
                                 ("Hair style", "hair_style", C.HAIR_STYLES),
                                 ("Hair color", "hair_color", list(range(len(C.HAIR_COLORS)))),
                                 ("Shirt", "shirt", list(range(len(C.CLOTH_COLORS)))),
                                 ("Pants", "pants", list(range(len(C.CLOTH_COLORS)))),
                                 ("Expression", "face", C.FACES)):
            self._refreshers.append(self._cycler(card, label, y, opts, key))
            y -= 0.14
        self._button(card, "START", (0, -0.7), self.game.begin_new_game, 0.065, 8)
        self._button(f, "< BACK", (-1.45, -0.9), self.game.go_main_menu, 0.05, 5)

    def refresh_character(self):
        for r in self._refreshers:
            r()

    # ---------------------------------------------------------------- settings
    def _build_settings(self, a2d):
        f = self._panel("settings", a2d, (-0.9, 0.9, -0.9, 0.9))
        self._label(f, "SETTINGS", (0, 0.76), 0.09, ACCENT)
        s = self.game.settings
        qualities = list(C.QUALITY_PRESETS)
        self._label(f, "Graphics quality", (-0.8, 0.6), 0.05, TEXT, TextNode.ALeft)
        self.q_label = self._label(f, s["quality"].upper(), (0.4, 0.6), 0.05, ACCENT)

        def q_step(d):
            i = (qualities.index(s["quality"]) + d) % len(qualities)
            s["quality"] = qualities[i]
            self.q_label["text"] = s["quality"].upper()
            self.game.apply_settings(restart_needed=True)
        self._button(f, "<", (0.1, 0.612), q_step, 0.05, 1.2, (-1,))
        self._button(f, ">", (0.7, 0.612), q_step, 0.05, 1.2, (1,))

        def slider(label, key, y, lo, hi):
            self._label(f, label, (-0.8, y), 0.05, TEXT, TextNode.ALeft)
            sl = DirectSlider(parent=f, range=(lo, hi), value=s[key], pageSize=(hi - lo) / 10, scale=0.4,
                              pos=(0.4, 0, y + 0.015), frameColor=(0.15, 0.2, 0.3, 1),
                              thumb_frameColor=ACCENT, thumb_relief=DGG.FLAT)

            def cmd():
                s[key] = float(sl["value"])
                self.game.apply_settings()
            sl["command"] = cmd
            return sl
        slider("Music volume", "music_volume", 0.45, 0.0, 1.0)
        slider("Effects volume", "sfx_volume", 0.32, 0.0, 1.0)
        slider("Mouse sensitivity", "mouse_sensitivity", 0.19, 0.03, 0.4)
        slider("Field of view", "fov", 0.06, 55, 110)

        def toggle(label, key, y):
            lab = self._label(f, "", (0.4, y), 0.05, ACCENT)
            self._label(f, label, (-0.8, y), 0.05, TEXT, TextNode.ALeft)

            def flip():
                s[key] = not s[key]
                lab["text"] = "ON" if s[key] else "OFF"
                self.game.apply_settings()
            lab["text"] = "ON" if s[key] else "OFF"
            self._button(f, "toggle", (0.7, y + 0.012), flip, 0.045, 3.5)
        toggle("Invert Y axis", "invert_y", -0.1)
        toggle("Show FPS", "show_fps", -0.23)
        toggle("Fullscreen", "fullscreen", -0.36)
        self._label(f, "Shadow/AA changes fully apply after restart.", (0, -0.55), 0.04, (0.6, 0.65, 0.75, 1))
        self._button(f, "BACK", (0, -0.75), self.game.settings_back, 0.065, 6)

    # ---------------------------------------------------------------- pause / end
    def _build_pause(self, a2d):
        f = self._panel("pause", a2d, (-0.5, 0.5, -0.65, 0.55))
        self._label(f, "PAUSED", (0, 0.38), 0.1, ACCENT)
        self._button(f, "RESUME", (0, 0.2), self.game.resume, 0.065, 7)
        self._button(f, "SAVE GAME", (0, 0.04), self.game.save_game, 0.065, 7)
        self._button(f, "SETTINGS", (0, -0.12), lambda: self.game.go_settings("pause"), 0.065, 7)
        self._button(f, "MAIN MENU", (0, -0.28), self.game.exit_to_menu, 0.065, 7)
        self.pause_msg = self._label(f, "", (0, -0.5), 0.045, (0.5, 1, 0.6, 1))

    def _build_end(self, a2d, name, title, color):
        f = self._panel(name, a2d, (-0.7, 0.7, -0.6, 0.55))
        self._label(f, title, (0, 0.36), 0.085, color)
        stats = self._label(f, "", (0, 0.15), 0.05)
        setattr(self, f"{name}_stats", stats)
        if name == "win":
            self._button(f, "MAIN MENU", (0, -0.2), self.game.exit_to_menu, 0.065, 7)
        else:
            self._button(f, "RETRY", (0, -0.05), self.game.retry, 0.065, 7)
            self._button(f, "MAIN MENU", (0, -0.25), self.game.exit_to_menu, 0.065, 7)

    # ---------------------------------------------------------------- HUD
    def _build_hud(self, a2d):
        hud = DirectFrame(parent=a2d, frameColor=(0, 0, 0, 0), frameSize=(-2, 2, -1, 1))
        self.hud = hud
        self.hp_bar = DirectWaitBar(parent=hud, range=100, value=100, barColor=(0.9, 0.2, 0.25, 1),
                                    frameColor=(0.05, 0.05, 0.08, 0.8), frameSize=(0, 0.6, -0.018, 0.018),
                                    pos=(-1.55, 0, -0.84), borderWidth=(0.005, 0.005))
        self.st_bar = DirectWaitBar(parent=hud, range=100, value=100, barColor=(0.2, 0.85, 0.4, 1),
                                    frameColor=(0.05, 0.05, 0.08, 0.8), frameSize=(0, 0.6, -0.012, 0.012),
                                    pos=(-1.55, 0, -0.9), borderWidth=(0.005, 0.005))
        OnscreenText(parent=hud, text="HP", pos=(-1.6, -0.855), scale=0.04, fg=TEXT, align=TextNode.ARight)
        OnscreenText(parent=hud, text="EN", pos=(-1.6, -0.91), scale=0.04, fg=TEXT, align=TextNode.ARight)
        self.score_text = OnscreenText(parent=hud, text="", pos=(1.6, 0.9), scale=0.06, fg=ACCENT,
                                       align=TextNode.ARight, mayChange=True)
        self.level_text = OnscreenText(parent=hud, text="", pos=(1.6, 0.82), scale=0.05, fg=TEXT,
                                       align=TextNode.ARight, mayChange=True)
        self.quest_text = OnscreenText(parent=hud, text="", pos=(1.6, 0.75), scale=0.045, fg=(0.85, 0.9, 1, 1),
                                       align=TextNode.ARight, mayChange=True, shadow=(0, 0, 0, 1))
        self.clock_text = OnscreenText(parent=hud, text="", pos=(-1.6, 0.9), scale=0.05, fg=TEXT,
                                       align=TextNode.ALeft, mayChange=True)
        self.prompt_text = OnscreenText(parent=hud, text="", pos=(0, -0.55), scale=0.055, fg=(1, 1, 0.6, 1),
                                        mayChange=True, shadow=(0, 0, 0, 1))
        self.msg_text = OnscreenText(parent=hud, text="", pos=(0, 0.6), scale=0.075, fg=(1, 1, 1, 1),
                                     mayChange=True, shadow=(0, 0, 0, 1))
        self.cross = OnscreenText(parent=hud, text="+", pos=(0, -0.015), scale=0.07, fg=(1, 1, 1, 0.8))

    def update_hud(self, player, quests, hour, prompt="", weather=""):
        self.hp_bar["value"] = player.health
        self.st_bar["value"] = player.stamina
        self.score_text.setText(f"SCORE {quests.score}")
        self.level_text.setText(f"Level {quests.level_index + 1}: {quests.level.name}")
        self.quest_text.setText("\n".join(quests.objective_lines()))
        h = int(hour)
        self.clock_text.setText(f"{h:02d}:{int((hour - h) * 60):02d}  {weather}")
        self.prompt_text.setText(prompt)
        if player.first_person:
            self.cross.show()
        else:
            self.cross.hide()

    def notify(self, text, duration=2.5):
        self.msg_queue.append((text, duration))

    def tick(self, dt):
        if self.msg_timer > 0:
            self.msg_timer -= dt
            if self.msg_timer <= 0:
                self.msg_text.setText("")
        if self.msg_timer <= 0 and self.msg_queue:
            text, dur = self.msg_queue.pop(0)
            self.msg_text.setText(text)
            self.msg_timer = dur
        a = self.damage.getColorScale()[3]
        if a > 0:
            self.damage.setColorScale(1, 1, 1, max(0.0, a - dt * 1.8))

    def flash_damage(self):
        self.damage["frameColor"] = (0.8, 0.0, 0.0, 0.4)
        self.damage.setColorScale(1, 1, 1, 1)

    def fade(self, callback):
        """Fade to black, run callback, fade back in."""
        self.fade_frame.show()
        self.fade_frame.setColorScale(1, 1, 1, 0)
        Sequence(LerpColorScaleInterval(self.fade_frame, 0.35, (1, 1, 1, 1), (1, 1, 1, 0)),
                 Func(callback),
                 LerpColorScaleInterval(self.fade_frame, 0.45, (1, 1, 1, 0), (1, 1, 1, 1)),
                 Func(self.fade_frame.hide)).start()
