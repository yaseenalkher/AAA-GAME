"""On-screen Android controls for NEON DISTRICT.

A drag joystick controls movement; tap buttons trigger actions. Panda3D's
Android pointer/touch mapping varies by build, so simultaneous multi-touch must
be checked on the actual handset before publishing.
"""
import math

from direct.gui.DirectGui import DirectButton, DirectFrame
from direct.gui import DirectGuiGlobals as DGG
from direct.task import Task


class MobileControls:
    JOY_X = -1.08
    JOY_Z = -0.66
    JOY_RADIUS = 0.31

    def __init__(self, game):
        self.game = game
        self.buttons = []
        self.visible = False
        self.joystick_active = False
        self.joystick = DirectFrame(
            parent=game.aspect2d, frameColor=(0.08, 0.12, 0.19, 0.62),
            frameSize=(-self.JOY_RADIUS, self.JOY_RADIUS,
                       -self.JOY_RADIUS, self.JOY_RADIUS),
            pos=(self.JOY_X, 0, self.JOY_Z),
        )
        self.knob = DirectFrame(
            parent=self.joystick, frameColor=(0.35, 0.72, 1.0, 0.78),
            frameSize=(-0.105, 0.105, -0.105, 0.105),
            pos=(0, 0, 0),
        )
        self.joystick.bind(DGG.B1PRESS, self._joy_start)
        self.joystick.bind(DGG.B1RELEASE, self._joy_end)

        self._make_tap("JUMP", self._jump, (0.92, 0, -0.38), 0.075)
        self._make_tap("HIT", self._attack, (1.17, 0, -0.62), 0.075)
        self._make_tap("TALK", self._interact, (0.88, 0, -0.86), 0.060)
        self._make_tap("CAM", self._camera, (1.20, 0, -0.91), 0.055)
        self._make_tap("PAUSE", self._pause, (0.98, 0, 0.88), 0.050)
        self._make_hold("RUN", "sprint", (1.20, 0, -0.24), 0.060)
        self.hide()

    def _make_hold(self, label, key, pos, scale):
        button = DirectButton(
            parent=self.game.aspect2d, text=label, text_scale=scale,
            text_fg=(1, 1, 1, 1), frameColor=(0.05, 0.08, 0.14, 0.72),
            frameSize=(-1.0, 1.0, -0.75, 0.75), relief=DGG.FLAT,
            pos=pos, scale=1.0, pad=(0.12, 0.12),
            rolloverSound=None, clickSound=None,
        )
        button.bind(DGG.B1PRESS, self._set_key, [key, True])
        button.bind(DGG.B1RELEASE, self._set_key, [key, False])
        self.buttons.append(button)
        return button

    def _make_tap(self, label, callback, pos, scale):
        button = DirectButton(
            parent=self.game.aspect2d, text=label, text_scale=scale,
            text_fg=(1, 1, 1, 1), frameColor=(0.05, 0.08, 0.14, 0.72),
            frameSize=(-1.0, 1.0, -0.75, 0.75), relief=DGG.FLAT,
            pos=pos, scale=1.0, pad=(0.12, 0.12),
            rolloverSound=None, clickSound=None, command=callback,
        )
        self.buttons.append(button)
        return button

    def _joy_start(self, *_):
        if self.game.state != "playing":
            return
        self.joystick_active = True
        self.game.taskMgr.add(self._update_joystick, "mobile-joystick-update")

    def _joy_end(self, *_):
        self.joystick_active = False
        self.game.taskMgr.remove("mobile-joystick-update")
        self._set_axis(0.0, 0.0)
        self.knob.setPos(0, 0, 0)

    def _update_joystick(self, task):
        if not self.joystick_active or not self.visible:
            self._joy_end()
            return Task.done
        watcher = self.game.mouseWatcherNode
        if watcher.hasMouse():
            pointer = watcher.getMouse()
            aspect = self.game.win.getXSize() / max(1, self.game.win.getYSize())
            pointer_x = pointer.getX() * aspect
            dx = (pointer_x - self.JOY_X) / self.JOY_RADIUS
            dz = (pointer.getY() - self.JOY_Z) / self.JOY_RADIUS
            length = math.hypot(dx, dz)
            if length > 1.0:
                dx, dz = dx / length, dz / length
            self.knob.setPos(dx * 0.18, 0, dz * 0.18)
            self._set_axis(dx, dz)
        return Task.cont

    def _set_axis(self, x, y):
        deadzone = 0.18
        self.game.keys["left"] = x < -deadzone
        self.game.keys["right"] = x > deadzone
        self.game.keys["forward"] = y > deadzone
        self.game.keys["back"] = y < -deadzone

    def _jump(self):
        if self.game.state == "playing":
            self.game._press("jump_pressed")

    def _attack(self):
        if self.game.state == "playing":
            self.game._press("attack_pressed")

    def _interact(self):
        if self.game.state == "playing":
            self.game.interact()

    def _camera(self):
        self.game._toggle_camera()

    def _pause(self):
        self.game.on_escape()

    def show(self):
        if self.visible:
            return
        self.visible = True
        self.joystick.show()
        self.knob.show()
        for button in self.buttons:
            button.show()

    def hide(self):
        if not self.visible:
            return
        self.visible = False
        self.joystick_active = False
        self.game.taskMgr.remove("mobile-joystick-update")
        self.joystick.hide()
        self.knob.hide()
        for button in self.buttons:
            button.hide()
        for key in ("forward", "back", "left", "right", "sprint"):
            self.game.keys[key] = False
