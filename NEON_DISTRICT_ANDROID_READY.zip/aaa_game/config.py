"""Global configuration, quality presets and default settings."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
GENERATED = ASSETS / "generated"
SHADERS = ROOT / "shaders"
# Android stores app data in its private writable directory.  Desktop keeps the
# original per-user location; NEON_DISTRICT_HOME can override both for testing.
import os
try:
    from panda3d.core import getUserAppDataDirectory
    _android_data_dir = Path(str(getUserAppDataDirectory("NEON_DISTRICT")))
except Exception:
    _android_data_dir = Path.home() / ".aaa_python_game"
SAVE_DIR = Path(os.environ.get("NEON_DISTRICT_HOME", str(_android_data_dir)))

GAME_TITLE = "NEON DISTRICT"
WINDOW_SIZE = (1600, 900)

# Day length in real seconds for a full 24h cycle.
DAY_LENGTH_SECONDS = 300.0
START_HOUR = 9.0

QUALITY_PRESETS = {
    "low": dict(shadow_size=512, msaa=0, bloom=False, ao=False,
                draw_distance=140, tree_lod_distance=40, particles=200,
                traffic=4, npcs=8, texture_size=256),
    "medium": dict(shadow_size=1024, msaa=2, bloom=True, ao=False,
                   draw_distance=220, tree_lod_distance=60, particles=450,
                   traffic=8, npcs=14, texture_size=512),
    "high": dict(shadow_size=2048, msaa=4, bloom=True, ao=True,
                 draw_distance=320, tree_lod_distance=80, particles=800,
                 traffic=12, npcs=20, texture_size=1024),
    "ultra": dict(shadow_size=4096, msaa=8, bloom=True, ao=True,
                  draw_distance=480, tree_lod_distance=110, particles=1400,
                  traffic=16, npcs=28, texture_size=1024),
    # Tuned as a conservative starting point for mid-range Android GPUs.
    # Validate and adjust on the target device after the first real build.
    "mobile": dict(shadow_size=512, msaa=0, bloom=False, ao=False,
                   draw_distance=160, tree_lod_distance=45, particles=250,
                   traffic=4, npcs=8, texture_size=256),
}

DEFAULT_SETTINGS = {
    "quality": "medium",
    "music_volume": 0.5,
    "sfx_volume": 0.8,
    "mouse_sensitivity": 0.12,
    "fov": 75,
    "invert_y": False,
    "fullscreen": False,
    "show_fps": False,
}

DEFAULT_APPEARANCE = {
    "body": "athletic",      # slim / athletic / broad
    "height": 1.78,
    "skin": 2,
    "hair_style": "short",   # bald / short / long / ponytail
    "hair_color": 1,
    "shirt": 3,
    "pants": 1,
    "face": "calm",
}

SKIN_TONES = [(0.96, 0.80, 0.69), (0.87, 0.67, 0.53), (0.76, 0.57, 0.42),
              (0.60, 0.42, 0.30), (0.42, 0.28, 0.20), (0.30, 0.20, 0.15)]
HAIR_COLORS = [(0.05, 0.04, 0.04), (0.20, 0.12, 0.07), (0.45, 0.28, 0.12),
               (0.80, 0.65, 0.35), (0.55, 0.15, 0.10), (0.55, 0.55, 0.58)]
CLOTH_COLORS = [(0.80, 0.15, 0.15), (0.15, 0.30, 0.75), (0.15, 0.55, 0.30),
                (0.10, 0.10, 0.12), (0.90, 0.90, 0.88), (0.90, 0.65, 0.10),
                (0.45, 0.20, 0.60), (0.25, 0.45, 0.50)]
BODY_TYPES = {"slim": 0.88, "athletic": 1.0, "broad": 1.15}
HAIR_STYLES = ["bald", "short", "long", "ponytail"]
FACES = ["calm", "smile", "angry", "surprised"]

KEYS = {
    "forward": "w", "back": "s", "left": "a", "right": "d",
    "sprint": "shift", "jump": "space", "interact": "e",
    "attack": "mouse1", "camera": "v", "pause": "escape",
    "save": "f5", "rain": "f6", "time": "f7",
}

PLAYER = dict(max_health=100.0, max_stamina=100.0, walk_speed=3.2, run_speed=7.0,
              stamina_drain=22.0, stamina_regen=16.0, jump_height=1.3,
              attack_damage=25.0, attack_range=2.2, attack_cooldown=0.55,
              radius=0.38, height=1.8)

SCORE = dict(coin=10, enemy=50, objective=100, level=250)
