"""Procedural audio: every sound is synthesised with numpy and written as WAV.

No external audio assets are needed. Replace any file in assets/generated/audio
with your own recording of the same name to override it (existing files are kept).
"""
import wave
from pathlib import Path

import numpy as np

SR = 22050


def _norm(x, peak=0.8):
    m = np.max(np.abs(x)) or 1.0
    return (x / m * peak).astype(np.float32)


def _env(n, attack=0.005, decay=0.1, sr=SR):
    t = np.arange(n) / sr
    a = np.minimum(1.0, t / max(attack, 1e-4))
    return a * np.exp(-t / max(decay, 1e-4))


def _lowpass(x, k):
    k = max(1, int(k))
    return np.convolve(x, np.ones(k) / k, mode="same")


def footstep(seed, bright=0.5):
    rng = np.random.default_rng(seed)
    n = int(SR * 0.16)
    noise = _lowpass(rng.standard_normal(n), 3 + int(8 * (1 - bright)))
    t = np.arange(n) / SR
    thump = np.sin(2 * np.pi * (70 + 20 * rng.random()) * t)
    return _norm((noise * 0.8 + thump * 0.6) * _env(n, 0.002, 0.045))


def jump():
    n = int(SR * 0.25)
    t = np.arange(n) / SR
    f = 200 + 500 * t / 0.25
    return _norm(np.sin(2 * np.pi * np.cumsum(f) / SR) * _env(n, 0.01, 0.1), 0.5)


def hit():
    rng = np.random.default_rng(3)
    n = int(SR * 0.3)
    t = np.arange(n) / SR
    body = np.sin(2 * np.pi * 110 * t * np.exp(-t * 6))
    return _norm((rng.standard_normal(n) * 0.5 + body) * _env(n, 0.001, 0.06))


def swing():
    rng = np.random.default_rng(5)
    n = int(SR * 0.22)
    x = _lowpass(rng.standard_normal(n), 6)
    t = np.arange(n) / SR
    return _norm(x * np.sin(np.pi * t / 0.22) ** 2, 0.45)


def pickup():
    parts = []
    for f in (880, 1320):
        n = int(SR * 0.12)
        t = np.arange(n) / SR
        parts.append(np.sin(2 * np.pi * f * t) * _env(n, 0.003, 0.08))
    return _norm(np.concatenate(parts), 0.6)


def ui_click():
    n = int(SR * 0.06)
    t = np.arange(n) / SR
    return _norm(np.sin(2 * np.pi * 600 * t) * _env(n, 0.001, 0.02), 0.5)


def fanfare(win=True):
    notes = [523, 659, 784, 1046] if win else [392, 330, 262, 196]
    parts = []
    for f in notes:
        n = int(SR * 0.22)
        t = np.arange(n) / SR
        parts.append((np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t)) * _env(n, 0.01, 0.25))
    return _norm(np.concatenate(parts), 0.6)


def voice_blip(pitch):
    """Short 'mumble' used for 3D NPC chatter."""
    parts = []
    rng = np.random.default_rng(int(pitch))
    for _ in range(4):
        n = int(SR * rng.uniform(0.07, 0.12))
        t = np.arange(n) / SR
        f = pitch * rng.uniform(0.9, 1.25)
        s = np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * 2 * f * t) + 0.25 * np.sin(2 * np.pi * 3 * f * t)
        parts.append(s * _env(n, 0.01, 0.07))
    return _norm(np.concatenate(parts), 0.45)


def wind_loop(seconds=8.0):
    rng = np.random.default_rng(11)
    n = int(SR * seconds)
    x = _lowpass(rng.standard_normal(n), 60)
    t = np.arange(n) / SR
    x *= 0.6 + 0.4 * np.sin(2 * np.pi * t / seconds * 2)  # whole cycles -> loops
    return _norm(_crossfade_loop(x), 0.35)


def rain_loop(seconds=6.0):
    rng = np.random.default_rng(13)
    n = int(SR * seconds)
    x = rng.standard_normal(n) - _lowpass(rng.standard_normal(n), 4)
    return _norm(_crossfade_loop(x), 0.35)


def traffic_loop(seconds=8.0):
    rng = np.random.default_rng(17)
    n = int(SR * seconds)
    t = np.arange(n) / SR
    rumble = _lowpass(rng.standard_normal(n), 120) * 3
    hum = np.sin(2 * np.pi * 55 * t) * 0.4
    return _norm(_crossfade_loop(rumble + hum), 0.3)


def _crossfade_loop(x, fade=2000):
    x = x.copy()
    w = np.linspace(0, 1, fade)
    x[:fade] = x[:fade] * w + x[-fade:] * (1 - w)
    return x[:-fade]


def music_loop(bpm=84, bars=8):
    """Ambient pad + soft arpeggio in A minor; whole number of bars so it loops."""
    beat = 60.0 / bpm
    n = int(SR * beat * 4 * bars)
    out = np.zeros(n, dtype=np.float64)
    chords = [(220.0, 261.63, 329.63), (174.61, 220.0, 261.63),
              (130.81, 196.0, 261.63), (196.0, 246.94, 293.66)]
    bar_len = int(SR * beat * 4)
    for b in range(bars):
        chord = chords[b % len(chords)]
        s0 = b * bar_len
        t = np.arange(bar_len) / SR
        pad = sum(np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 2.003 * t) for f in chord)
        swell = np.sin(np.pi * np.arange(bar_len) / bar_len) ** 1.5
        out[s0:s0 + bar_len] += pad * swell * 0.12
        step = int(SR * beat / 2)
        for k in range(8):
            f = chord[k % 3] * 2
            m = min(step * 2, bar_len - k * step)
            if m <= 0:
                break
            tt = np.arange(m) / SR
            out[s0 + k * step:s0 + k * step + m] += np.sin(2 * np.pi * f * tt) * _env(m, 0.005, 0.35) * 0.09
        bass = np.sin(2 * np.pi * chord[0] / 2 * t) * 0.18
        out[s0:s0 + bar_len] += bass * swell
    return _norm(out, 0.6)


SOUND_BUILDERS = {
    "step1": lambda: footstep(1, 0.6), "step2": lambda: footstep(2, 0.4),
    "step3": lambda: footstep(3, 0.5),
    "jump": jump, "hit": hit, "swing": swing, "pickup": pickup, "click": ui_click,
    "win": lambda: fanfare(True), "lose": lambda: fanfare(False),
    "voice1": lambda: voice_blip(180), "voice2": lambda: voice_blip(230),
    "voice3": lambda: voice_blip(140),
    "wind": wind_loop, "rain": rain_loop, "traffic": traffic_loop, "music": music_loop,
}


def write_wav(path, data):
    pcm = np.clip(data, -1, 1)
    pcm = (pcm * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def ensure_audio(directory):
    """Generate any missing sound; returns dict name -> Path."""
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    result = {}
    for name, build in SOUND_BUILDERS.items():
        p = d / f"{name}.wav"
        if not p.exists():
            write_wav(p, build())
        result[name] = p
    return result
