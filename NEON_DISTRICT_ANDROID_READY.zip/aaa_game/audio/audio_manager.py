"""Audio facade: music, SFX, ambience and 3D positional voices (OpenAL via Panda3D)."""
import random

import config as C


class AudioManager:
    def __init__(self, base, settings):
        self.base = base
        self.ok = True
        self.sounds = {}
        self.loops = {}
        self.a3d = None
        self._step_i = 0
        try:
            from direct.showbase.Audio3DManager import Audio3DManager
            audio_dir = C.GENERATED / "audio"
            audio_dir.mkdir(parents=True, exist_ok=True)
            self.paths = {p.stem: p for p in audio_dir.glob("*.wav")}
            required = {"step1", "step2", "step3", "jump", "hit", "swing", "pickup",
                        "click", "win", "lose", "voice1", "voice2", "voice3", "wind",
                        "rain", "traffic", "music"}
            missing = required.difference(self.paths)
            if missing:
                print("[audio] missing bundled audio files:", ", ".join(sorted(missing)))
            for name, p in self.paths.items():
                if name in ("music",):
                    self.loops[name] = base.loader.loadMusic(str(p))
                elif name in ("wind", "rain", "traffic"):
                    self.loops[name] = base.loader.loadSfx(str(p))
                else:
                    self.sounds[name] = base.loader.loadSfx(str(p))
            for s in self.loops.values():
                s.setLoop(True)
            self.a3d = Audio3DManager(base.sfxManagerList[0], base.camera)
            self.a3d.setDropOffFactor(0.35)
            self.a3d.setDistanceFactor(1.0)
        except Exception as e:  # no audio device etc.
            print("[audio] disabled:", e)
            self.ok = False
        self.apply_settings(settings)

    def apply_settings(self, settings):
        if not self.ok:
            return
        self.base.musicManager.setVolume(settings["music_volume"])
        self.base.sfxManagerList[0].setVolume(settings["sfx_volume"])

    # ---- 2D ------------------------------------------------------
    def play(self, name, volume=1.0, rate=1.0):
        if not self.ok or name not in self.sounds:
            return
        s = self.sounds[name]
        s.setVolume(volume)
        s.setPlayRate(rate)
        s.play()

    def footstep(self, running=False):
        self._step_i = (self._step_i + 1) % 3
        self.play(f"step{self._step_i + 1}", 0.7 if running else 0.45, random.uniform(0.9, 1.1))

    def start_loop(self, name, volume):
        if self.ok and name in self.loops:
            s = self.loops[name]
            s.setVolume(volume)
            if s.status() != s.PLAYING:
                s.play()

    def set_loop_volume(self, name, volume):
        if self.ok and name in self.loops:
            s = self.loops[name]
            s.setVolume(max(0.0, min(1.0, volume)))
            if volume > 0.01 and s.status() != s.PLAYING:
                s.play()
            elif volume <= 0.01 and s.status() == s.PLAYING:
                s.stop()

    def stop_all_loops(self):
        if self.ok:
            for s in self.loops.values():
                s.stop()

    def start_music(self):
        self.start_loop("music", 0.8)

    # ---- 3D ------------------------------------------------------
    def make_voice(self, nodepath, name="voice1"):
        if not self.ok or self.a3d is None:
            return None
        snd = self.a3d.loadSfx(str(self.paths[name]))
        self.a3d.attachSoundToObject(snd, nodepath)
        snd.setVolume(1.0)
        return snd

    def play_at(self, name, nodepath):
        s = self.make_voice(nodepath, name)
        if s:
            s.play()
        return s

    def release_voice(self, snd):
        if self.ok and self.a3d is not None and snd is not None:
            try:
                snd.stop()
                self.a3d.detachSound(snd)
            except Exception:
                pass
