"""Levels, objectives, scoring. Pure Python."""
from dataclasses import dataclass, field

from config import SCORE


@dataclass
class Objective:
    kind: str            # coin | enemy | talk | reach
    target: int
    text: str
    progress: int = 0

    @property
    def done(self):
        return self.progress >= self.target

    def label(self):
        if self.kind in ("coin", "enemy"):
            return f"{self.text} ({min(self.progress, self.target)}/{self.target})"
        return self.text + (" [done]" if self.done else "")


@dataclass
class LevelDef:
    name: str
    intro: str
    objectives: list = field(default_factory=list)


def default_levels():
    return [
        LevelDef("Welcome to the District", "Get your bearings. Talk to the guide in the park.",
                 [Objective("talk", 1, "Talk to the guide (E)"),
                  Objective("coin", 8, "Collect coins")]),
        LevelDef("Street Trouble", "Thugs are harassing the locals. Clear them out.",
                 [Objective("enemy", 3, "Defeat thugs (LMB)"),
                  Objective("coin", 10, "Collect coins")]),
        LevelDef("The Beacon", "Finish the job and reach the beacon in the park.",
                 [Objective("enemy", 5, "Defeat thugs"),
                  Objective("coin", 12, "Collect coins"),
                  Objective("reach", 1, "Reach the beacon")]),
    ]


class QuestManager:
    def __init__(self, levels=None):
        self.levels = levels or default_levels()
        self.level_index = 0
        self.score = 0
        self.kills = 0
        self.coins = 0
        self.finished = False
        self.log = []

    # ---- queries -------------------------------------------------
    @property
    def level(self):
        return self.levels[min(self.level_index, len(self.levels) - 1)]

    @property
    def level_complete(self):
        return all(o.done for o in self.level.objectives)

    def needs(self, kind):
        return any(o.kind == kind and not o.done for o in self.level.objectives)

    def objective_lines(self):
        return [o.label() for o in self.level.objectives]

    # ---- events --------------------------------------------------
    def notify(self, kind, amount=1):
        """Report a game event; returns True when this event completed an objective."""
        if kind == "coin":
            self.coins += amount
            self.score += SCORE["coin"] * amount
        elif kind == "enemy":
            self.kills += amount
            self.score += SCORE["enemy"] * amount
        completed = False
        for o in self.level.objectives:
            if o.kind == kind and not o.done:
                o.progress += amount
                if o.done:
                    completed = True
                    self.score += SCORE["objective"]
                    self.log.append(f"Objective complete: {o.text}")
        return completed

    def advance(self):
        """Call after level_complete; returns True if another level follows."""
        assert self.level_complete
        self.score += SCORE["level"]
        if self.level_index + 1 >= len(self.levels):
            self.finished = True
            return False
        self.level_index += 1
        return True

    # ---- persistence ---------------------------------------------
    def to_dict(self):
        return dict(level_index=self.level_index, score=self.score, kills=self.kills,
                    coins=self.coins, finished=self.finished,
                    progress=[o.progress for o in self.level.objectives])

    def load_dict(self, d):
        self.level_index = max(0, min(int(d.get("level_index", 0)), len(self.levels) - 1))
        self.score = int(d.get("score", 0))
        self.kills = int(d.get("kills", 0))
        self.coins = int(d.get("coins", 0))
        self.finished = bool(d.get("finished", False))
        for o, p in zip(self.level.objectives, d.get("progress", [])):
            o.progress = int(p)
