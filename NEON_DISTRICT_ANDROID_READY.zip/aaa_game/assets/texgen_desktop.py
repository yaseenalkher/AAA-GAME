"""Procedural, tileable PBR-style texture generation (numpy + Pillow).

Produces albedo maps (and a few normal maps) into assets/generated/textures.
Drop your own PNGs with the same file names into that folder to override them
(existing files are never overwritten).
"""
from pathlib import Path

# Optional generation dependencies are loaded only when a texture is missing.
# Android builds ship pre-generated PNGs and therefore need no NumPy/Pillow.
np = None
Image = None


def _load_generation_deps():
    global np, Image
    if np is None or Image is None:
        import numpy as _np
        from PIL import Image as _Image
        np, Image = _np, _Image


def _fbm(size, rng, octaves=5, persistence=0.55, base=4):
    """Tileable fractal noise in 0..1 (periodic by construction: FFT filtered noise)."""
    total = np.zeros((size, size))
    amp = 1.0
    for o in range(octaves):
        res = min(base * 2 ** o, size)
        grid = rng.random((res, res))
        # periodic bicubic-ish upsample using FFT zero padding
        f = np.fft.fftshift(np.fft.fft2(grid))
        pad = np.zeros((size, size), dtype=complex)
        lo = size // 2 - res // 2
        pad[lo:lo + res, lo:lo + res] = f
        up = np.real(np.fft.ifft2(np.fft.ifftshift(pad)))
        up = (up - up.min()) / (np.ptp(up) + 1e-9)
        total += up * amp
        amp *= persistence
    total -= total.min()
    return total / (total.max() + 1e-9)


def _save(arr, path):
    arr = np.clip(arr, 0, 1)
    Image.fromarray((arr * 255).astype(np.uint8)).save(path)


def _normal_from_height(h, strength=2.0):
    gx = np.roll(h, -1, 1) - np.roll(h, 1, 1)
    gy = np.roll(h, -1, 0) - np.roll(h, 1, 0)
    n = np.dstack([-gx * strength, gy * strength, np.ones_like(h)])
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    return n * 0.5 + 0.5


def asphalt(size, rng):
    n = _fbm(size, rng, 6, 0.6, 8)
    grain = rng.random((size, size)) * 0.15
    v = 0.16 + 0.12 * n + grain * 0.4
    return np.dstack([v, v, v * 1.03]), n


def grass(size, rng):
    n = _fbm(size, rng, 6, 0.6, 6)
    fine = rng.random((size, size))
    r = 0.14 + 0.10 * n + 0.04 * fine
    g = 0.34 + 0.22 * n + 0.10 * fine
    b = 0.10 + 0.05 * n
    return np.dstack([r, g, b]), n


def pavement(size, rng):
    n = _fbm(size, rng, 5, 0.5, 8)
    v = 0.55 + 0.12 * n + rng.random((size, size)) * 0.04
    tile = size // 4
    lines = np.zeros((size, size))
    lines[::tile, :] = 1
    lines[:, ::tile] = 1
    lines = _blur(lines, 1)
    v = v * (1 - 0.35 * np.clip(lines * 3, 0, 1))
    img = np.dstack([v, v * 0.98, v * 0.95])
    return img, n * 0.5 + (1 - lines) * 0.5


def _blur(a, r):
    out = a.copy()
    for ax in (0, 1):
        out = sum(np.roll(out, s, ax) for s in range(-r, r + 1)) / (2 * r + 1)
    return out


def road_markings(size, rng):
    """Road albedo with a dashed centre line along V."""
    img, n = asphalt(size, rng)
    img = img.copy()
    c = size // 2
    w = max(2, size // 64)
    for y in range(size):
        if (y // (size // 8)) % 2 == 0:
            img[y, c - w:c + w] = (0.85, 0.75, 0.25)
    return img, n


def facade(size, rng, style):
    """Building facade tile covering 4m x 4m per UV unit with windows."""
    h = _fbm(size, rng, 4, 0.5, 8)
    if style == 0:      # brick
        base = np.dstack([0.50 + 0.15 * h, 0.22 + 0.08 * h, 0.17 + 0.06 * h])
        rows = size // 16
        mortar = np.zeros((size, size))
        for r in range(0, size, rows):
            mortar[r:r + 1, :] = 1
            off = (rows * 2 if (r // rows) % 2 else 0)
            for c in range(off % (rows * 2), size, rows * 2):
                mortar[r:r + rows, c:c + 1] = 1
        base = base * (1 - 0.35 * mortar[..., None])
        win_c = (0.10, 0.14, 0.20)
        lit_c = (1.0, 0.85, 0.5)
    elif style == 1:    # glass curtain wall
        base = np.dstack([0.22 + 0.1 * h, 0.35 + 0.1 * h, 0.45 + 0.1 * h])
        win_c = (0.12, 0.22, 0.32)
        lit_c = (0.95, 0.95, 0.8)
    else:               # concrete
        base = np.dstack([0.62 + 0.1 * h] * 3)
        win_c = (0.08, 0.1, 0.14)
        lit_c = (1.0, 0.9, 0.6)
    img = base.copy()
    emissive = np.zeros((size, size))
    cols, rws = 4, 4
    cw, rh = size // cols, size // rws
    for r in range(rws):
        for c in range(cols):
            y0, y1 = r * rh + rh // 5, (r + 1) * rh - rh // 4
            x0, x1 = c * cw + cw // 6, (c + 1) * cw - cw // 6
            if style == 1:
                y0, y1, x0, x1 = r * rh + 2, (r + 1) * rh - 2, c * cw + 2, (c + 1) * cw - 2
            lit = rng.random() < 0.35
            col = np.array(lit_c if lit else win_c)
            img[y0:y1, x0:x1] = col * (0.8 + 0.2 * h[y0:y1, x0:x1, None])
            if lit:
                emissive[y0:y1, x0:x1] = 1
    return img, h, emissive


def bark(size, rng):
    n = _fbm(size, rng, 5, 0.6, 4)
    stripes = 0.5 + 0.5 * np.sin(np.linspace(0, 40, size))[None, :] * 0.4
    v = (0.2 + 0.2 * n) * stripes
    return np.dstack([v * 1.2, v * 0.85, v * 0.6]), n


def leaves(size, rng):
    n = _fbm(size, rng, 6, 0.65, 6)
    return np.dstack([0.08 + 0.1 * n, 0.30 + 0.3 * n, 0.06 + 0.06 * n]), n


def ensure_textures(directory, size=512, seed=5):
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    expected = ["asphalt", "grass", "pavement", "road", "bark", "leaves",
                "facade0", "facade1", "facade2"]
    if all((d / f"{name}.png").is_file() for name in expected):
        return {name: d / f"{name}.png" for name in expected}
    _load_generation_deps()
    rng = np.random.default_rng(seed)
    jobs = {
        "asphalt": lambda: asphalt(size, rng),
        "grass": lambda: grass(size, rng),
        "pavement": lambda: pavement(size, rng),
        "road": lambda: road_markings(size, rng),
        "bark": lambda: bark(size, rng),
        "leaves": lambda: leaves(size, rng),
    }
    out = {}
    for name, fn in jobs.items():
        p = d / f"{name}.png"
        pn = d / f"{name}_n.png"
        if not p.exists():
            img, h = fn()
            _save(img, p)
            _save(_normal_from_height(h), pn)
        out[name] = p
    for style in range(3):
        p = d / f"facade{style}.png"
        pn = d / f"facade{style}_n.png"
        pe = d / f"facade{style}_e.png"
        if not p.exists():
            img, h, em = facade(size, rng, style)
            _save(img, p)
            _save(_normal_from_height(h, 1.0), pn)
            _save(np.dstack([em] * 3), pe)
        out[f"facade{style}"] = p
    return out
