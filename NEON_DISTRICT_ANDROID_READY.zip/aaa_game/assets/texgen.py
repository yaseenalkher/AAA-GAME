"""Runtime texture lookup.

Android release builds include pre-generated PNG files so the runtime does not
need NumPy/Pillow native extensions. Generate or regenerate them on desktop
with scripts/generate_assets.py.
"""
from pathlib import Path


def ensure_textures(directory, size=512, seed=5):
    directory = Path(directory)
    names = ["asphalt", "grass", "pavement", "road", "bark", "leaves",
             "facade0", "facade1", "facade2"]
    missing = [name for name in names if not (directory / f"{name}.png").is_file()]
    if missing:
        raise FileNotFoundError(
            "Missing generated textures: " + ", ".join(missing) +
            ". Run `python scripts/generate_assets.py` on a desktop environment."
        )
    return {name: directory / f"{name}.png" for name in names}
