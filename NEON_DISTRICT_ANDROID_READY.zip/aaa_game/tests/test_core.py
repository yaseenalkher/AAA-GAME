import math
import os
import random
import sys
import tempfile
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ai.npc_ai import NpcBrain
from animations import procedural as anim
from environments import daycycle
from environments.layout import CityLayout, Rect
from gameplay.quests import QuestManager
from physics.simple_collision import make_resolver, push_out_circle_rect
from save_system.save_manager import SaveManager
from utils import geometry as geo


# ---------------- geometry ----------------
def test_meshes_valid():
    for m in (geo.box(1, 2, 3), geo.plane(2, 2), geo.cylinder(1, 0.2, 2), geo.sphere(1),
              geo.tapered_limb(0.1, 0.07, 0.4)):
        assert m.validate() and m.tris
    lo, hi = geo.box(2, 4, 6, centered=False).bounds()
    assert lo[2] == 0 and hi[2] == 6


def test_normals_unit_and_outward():
    s = geo.sphere(2, 12, 8)
    for (x, y, z), (nx, ny, nz) in zip(s.verts, s.normals):
        assert abs(math.sqrt(nx * nx + ny * ny + nz * nz) - 1) < 1e-6
        assert x * nx + y * ny + z * nz > 0
    # triangle winding is outward (CCW seen from outside)
    for a, b, c in s.tris:
        pa, pb, pc = s.verts[a], s.verts[b], s.verts[c]
        u = [pb[i] - pa[i] for i in range(3)]
        v = [pc[i] - pa[i] for i in range(3)]
        n = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
        cen = [(pa[i] + pb[i] + pc[i]) / 3 for i in range(3)]
        assert sum(n[i] * cen[i] for i in range(3)) >= -1e-9


def test_box_winding_outward():
    b = geo.box(2, 2, 2)
    for a, bb, c in b.tris:
        pa, pb, pc = b.verts[a], b.verts[bb], b.verts[c]
        u = [pb[i] - pa[i] for i in range(3)]
        v = [pc[i] - pa[i] for i in range(3)]
        n = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
        assert sum(n[i] * pa[i] for i in range(3)) > 0


# ---------------- layout ----------------
def test_layout_deterministic_and_clear_spawn():
    a, b = CityLayout(seed=3), CityLayout(seed=3)
    assert [x.rect for x in a.buildings] == [x.rect for x in b.buildings]
    assert a.is_free(*a.spawn_point, 0.5)
    assert len(a.buildings) == 24 * 4
    for bl in a.buildings:   # buildings stay inside their block
        assert any(r.contains(bl.rect.x0, bl.rect.y0) and r.contains(bl.rect.x1, bl.rect.y1)
                   for r in a.block_rects)


def test_random_points_free():
    lay = CityLayout()
    rng = random.Random(1)
    for _ in range(100):
        x, y = lay.random_free_point(rng)
        assert lay.is_free(x, y, 0.8)


# ---------------- collision ----------------
def test_push_out():
    r = Rect(0, 0, 4, 4)
    x, y = push_out_circle_rect(-0.2, 2, 0.5, r)
    assert x <= -0.5 + 1e-9
    x, y = push_out_circle_rect(2, 2, 0.5, r)   # centre inside
    assert not r.contains(x, y, -0.49)
    res = make_resolver([r], half_extent=100)
    assert res(500, 0, 0.5)[0] <= 99.5


# ---------------- AI ----------------
def test_thug_chases_and_attacks():
    t = NpcBrain("thug", 0, 0, random.Random(1))
    got = []
    for _ in range(600):
        got += t.step(0.05, (5, 0))
    assert t.state in ("chase", "attack")
    assert any(e[0] == "attack" for e in got)
    assert math.hypot(t.x - 5, t.y) < 2.0


def test_thug_ignores_far_player():
    t = NpcBrain("thug", 0, 0, random.Random(1))
    for _ in range(100):
        t.step(0.05, (200, 0))
    assert t.state in ("idle", "wander")


def test_civilian_flees_and_dies():
    c = NpcBrain("civilian", 0, 0, random.Random(2))
    c.take_hit(5, (-1, 0))
    assert c.state == "flee"
    for _ in range(40):
        c.step(0.05, (-1, 0))
    assert c.x > 1.0
    assert c.take_hit(1000, (0, 0)) is True and not c.alive


def test_guide_never_hurt():
    g = NpcBrain("guide", 0, 0)
    assert g.take_hit(1000, (1, 1)) is False and g.alive


def test_wander_stays_in_bounds():
    c = NpcBrain("civilian", 0, 0, random.Random(5), bounds=30)
    for _ in range(4000):
        c.step(0.05, (500, 500))
    assert abs(c.x) < 32 and abs(c.y) < 32


# ---------------- quests ----------------
def test_quest_flow_and_persistence():
    q = QuestManager()
    assert not q.level_complete
    q.notify("talk")
    for _ in range(8):
        q.notify("coin")
    assert q.level_complete
    s = q.score
    assert q.advance() and q.level_index == 1
    assert q.score > s
    q.notify("enemy", 2)
    d = q.to_dict()
    q2 = QuestManager()
    q2.load_dict(d)
    assert q2.level_index == 1 and q2.score == q.score and "(2/3)" in q2.objective_lines()[0]
    # finish the game
    for _ in range(3):
        for o in q.level.objectives:
            q.notify(o.kind, o.target)
        if q.level_complete:
            q.advance()
    assert q.finished


# ---------------- save ----------------
def test_save_roundtrip_and_corruption():
    with tempfile.TemporaryDirectory() as d:
        sm = SaveManager(d)
        assert sm.load_game(0) is None
        sm.save_game(0, {"hp": 5})
        assert sm.load_game(0) == {"hp": 5} and sm.latest_slot() == 0
        sm.slot_path(1).write_text("{broken")
        assert sm.load_game(1) is None
        s = sm.load_settings()
        s["fov"] = 90
        sm.save_settings(s)
        assert sm.load_settings()["fov"] == 90
        (Path(d) / "settings.json").write_text('{"fov": "bad", "unknown": 1}')
        assert sm.load_settings()["fov"] == 75


# ---------------- animation ----------------
def test_anim_poses_finite_and_bounded():
    for state in ("idle", "move", "air", "attack", "hit", "dead"):
        for i in range(60):
            p = anim.pose_for(state, i * 0.1, speed=5, phase=i * 0.3, vz=3 - i * 0.1,
                              state_t=i / 60, run_amount=1.0)
            assert set(anim.JOINTS) <= set(p)
            assert all(math.isfinite(v) and abs(v) < 200 for v in p.values()), (state, p)


def test_walk_cycle_alternates_and_knees_bend_backwards():
    a = anim.locomotion_pose(math.pi / 2, 0)
    b = anim.locomotion_pose(-math.pi / 2, 0)
    assert a["hipL"] > 0 > a["hipR"] and b["hipL"] < 0 < b["hipR"]
    for i in range(100):
        p = anim.locomotion_pose(i * 0.2, 0.5)
        assert p["kneeL"] <= 0 and p["kneeR"] <= 0


def test_stride_frequency_monotonic():
    assert anim.stride_frequency(1) < anim.stride_frequency(7)


# ---------------- day cycle ----------------
def test_daycycle():
    for h in [i * 0.25 for i in range(97)]:
        d = daycycle.sample(h)
        assert all(0 <= c <= 1.2 for key in ("sky", "sun", "ambient") for c in d[key])
        assert daycycle.sun_direction(h)[2] > 0
    assert daycycle.star_alpha(12) == 0 and daycycle.star_alpha(1) == 1
    assert sum(daycycle.sample(12)["sky"]) > sum(daycycle.sample(1)["sky"])
    w = daycycle.WeatherSystem(seed=2)
    seen = set()
    for _ in range(20000):
        w.update(0.1)
        seen.add(w.state)
        assert 0 <= w.rain <= 1.0001
    assert len(seen) >= 3
    w.force("rain")
    for _ in range(300):
        w.update(0.1)
    assert w.rain > 0.9


# ---------------- audio / textures ----------------
def test_audio_generation():
    from audio import synth
    with tempfile.TemporaryDirectory() as d:
        files = synth.ensure_audio(d)
        assert len(files) == len(synth.SOUND_BUILDERS)
        for name, p in files.items():
            with wave.open(str(p)) as w:
                assert w.getnframes() > 500, name
        with wave.open(str(files["music"])) as w:
            assert w.getnframes() / w.getframerate() > 20


def test_texture_generation():
    from assets import texgen_desktop as texgen
    from PIL import Image
    with tempfile.TemporaryDirectory() as d:
        out = texgen.ensure_textures(d, size=128)
        assert len(out) == 9
        for p in out.values():
            im = Image.open(p)
            assert im.size == (128, 128)
            assert im.getextrema() is not None


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-q"]))


def test_mobile_quality_preset_is_conservative():
    import config
    mobile = config.QUALITY_PRESETS["mobile"]
    assert mobile["msaa"] == 0
    assert mobile["bloom"] is False
    assert mobile["ao"] is False
    assert mobile["npcs"] <= 8
    assert mobile["texture_size"] <= 256
